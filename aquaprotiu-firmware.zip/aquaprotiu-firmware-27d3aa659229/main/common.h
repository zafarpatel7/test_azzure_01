#ifndef _COMMON_H_
#define _COMMON_H_
/********** Include all file *****/
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "freertos/queue.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_event_loop.h"
#include "esp_log.h"
#include "esp_wpa2.h"
#include "tcpip_adapter.h"
#include "esp_smartconfig.h"
#include "driver/uart.h"
#include "soc/uart_struct.h"
#include "string.h"
#include "nvs_flash.h"
#include "esp_ota_ops.h"
#include "esp_http_client.h"
#include "esp_flash_partitions.h"
#include "esp_partition.h"

#define ESP_VER_MAJOR "esp_ver_major"
#define ESP_VER_MINOR "esp_ver_minor"

#define MCU_VER_MAJOR "mcu_ver_major"
#define MCU_VER_MINOR "mcu_ver_minor"

#define DEVICE_SERIAL_NUM "sno"
#define AZURE_CONNECTION_STR "azure_str"

#define MCU_DOWNLOAD_IMG "mcu_new"
#define MCU_DOWNLOAD_IMG_SIZE "mcu_img_size"

#define MCU_BACKUP "mcu_bck"
#define MCU_BACKUP_SIZE "mcu_bck_size"
#define MCU_BACKUP_VER_MAJOR "mcu_bck_major"
#define MCU_BACKUP_VER_MINOR "mcu_bck_minor"

#define PRODUCT_NAME "iNemo"
#define FOTA_PENDING_STATUS "FOTA_pend"

/************** All MCU Commands **********/
#define INVALID_JSON "INVALID#"



/************** All JSON Tag ***************/
#define FOTA_PACKET_ID "A5"

#define HTTP_GET (1)
#define HTTP_POST (2)


#define QUEUE_LENGTH (2)
#define MAX_PAYLOAD_SIZE (64)
//#define BLINK_GPIO (GPIO_NUM_13)
//@harshal : Added 27/05/2020 as per the requirement from Zafar
#define BLINK_GPIO (GPIO_NUM_18)


#define WIFI_SERVICE_TXQ_TIMEOUT 			100   /*The maximum amount of time the task
											should block waiting for an item*/

/***** Enable or Disable the Thread ******/
#define ENABLE_SERVICE_AZURE
#define ENABLE_SERVICE_WIFI
#define ENABLE_SERVICE_FOTA
#define ENABLE_SERVICE_LED
//#define ENABLE_SERVICE_DI
#define ENABLE_SERVICE_SERIAL_COMM


/* Bits used by all tasks. */
#define WIFI_SERVICE_BIT        		( 1 << 0 )
#define AZURE_SERVICE_BIT  			( 1 << 1 )
#define HTTP_SERVER_BIT       			( 1 << 2 )
#define LED_CONTROL_SERVICE_BIT     		( 1 << 3 )
#define SERIAL_COMM_SERVICE_BIT     		( 1 << 4 )
#define DIAGNOSTIC_SERVICE_BIT      		( 1 << 5 )
#define DATA_INDICATION_SERVICE_BIT 		( 1 << 6 )
#define FOTA_SERVICE_BIT      			( 1 << 7 )
#define SYNC_ALL_TASK_BIT     			( 1 << 8 )

/********** All Events Riase from all services **********/
// Wifi events
#define COMM_WIFI_CONNECTED 		       	( 1 << 0 )
#define COMM_WIFI_DISCONNECT  			( 1 << 1 )
#define COMM_SMARTCONFIG_IN_PROGRESS		( 1 << 2 )
#define COMM_SMARTCONFIG_DONE			( 1 << 3 )
#define COMM_SMARTCONFIG_START			( 1 << 4 )

//MCU Events
#define COMM_SEND_TIME_TO_MCU			( 1 << 5 )
#define COMM_SEND_DATA_TO_MCU			( 1 << 6 )
#define COMM_SEND_PWR_PACKET			( 1 << 7 )

//Azure Events
#define COMM_AZURE_CONNECTED     		( 1 << 8 )
#define COMM_AZURE_DISCONNECTED	        	( 1 << 9 )
#define COMM_AZURE_SEND_COMMAND			( 1 << 10 )
#define COMM_AZURE_CHANGE_CSTR_REQ		( 1 << 11 )
#define COMM_AZURE_FOTA_REQUEST			( 1 << 12 )
#define COMM_AZURE_FOTA_ACK			( 1 << 13 )

//FOTA events
#define COMM_MCU_FOTA_COMPLETED	        	( 1 << 14 )
#define COMM_ESP_FOTA_STARTED	        	( 1 << 15 )
#define COMM_ESP_FOTA_COMPLETED	        	( 1 << 16 )
#define COMM_START_MCU_FOTA			( 1 << 17 )
#define COMM_START_ESP_FOTA			( 1 << 18 )
#define COMM_MCU_FOTA_UPGRADE_START		( 1 << 19 )
#define COMM_START_BOTH_FOTA			( 1 << 20 )

#define SYNC_ALL_TASK (	WIFI_SERVICE_BIT 		| AZURE_SERVICE_BIT 		| HTTP_SERVER_BIT 		|	\
						LED_CONTROL_SERVICE_BIT | SERIAL_COMM_SERVICE_BIT 	| DIAGNOSTIC_SERVICE_BIT| 	\
						DATA_INDICATION_SERVICE_BIT | FOTA_SERVICE_BIT | SYNC_ALL_TASK_BIT )

/*********  All extern variables *******/
extern int g_u32Delay;
extern int g_u32TaskSyncTime;
extern EventGroupHandle_t g_xEventGroup;
extern EventGroupHandle_t g_xServiceStatEventGroup;
extern EventGroupHandle_t g_xSmartConfigEventGroup;
extern char _gu8ConnectoinString[256];
extern char g_Serial_Number[16];
extern unsigned char g_MCU_powerOn;
typedef void * QueueHandle_t;

//Wifi state
typedef enum
{
	WIFI_INIT = 1,
	WIFI_START,
	WIFI_CONNECTING,
	WIFI_CONNECTED,
	WIFI_DEINIT,
	WIFI_DISCONNECT,
	WIFI_CHECK_USER_SSID_PASS,
	WIFI_GET_USER_SSID_PASS,
	WIFI_RECONNECT,
	WIFI_WAIT
} e_wifi_state_type;

//Azure state
typedef enum
{
	AZURE_INIT = 1,
	AZURE_CONNECT,
	AZURE_DISCONNECT,
	AZURE_DEINIT,
	AZURE_CHECK_CONNECTION_STRING,
	AZURE_GET_CONNECTION_STRING,
	AZURE_WAIT
} azure_stat_machine;

//Data Indication state
typedef enum
{
	DI_INIT = 1,
	DI_DATA_FROM_AZURE,
	DI_DATA_FROM_MCU,
	DI_DATA_SEND_TO_AZURE,
	DI_DATA_SEND_TO_MCU,
	DI_OFF,
	DI_WAIT
} e_data_indication_stat;

//FOTA state
typedef enum
{
	FOTA_INIT = 1,
	FOTA_MCU_START,
	FOTA_MCU_UPGRADE,
	FOTA_ESP_START,
	FOTA_ESP_COMPLETED,
	FOTA_START_BOTH,
	FOTA_WAIT	
} e_fota_stat;

//LED Indication state
typedef enum
{
	LED_INIT = 1,	
	LED_WIFI_SMART_CONFIG,
	LED_WIFI_DISCONNECTED,
	LED_INTERNET_NOT_AVAILABLE,
	LED_FAIL_TO_CONNECTING_TO_AZURE,
	LED_WIFI_N_AZURE_CON_SUCCESSFULLY,
	LED_WAIT
} e_led_control_stat;

//Message Info
typedef struct _msg_info
{
	unsigned char service_id;
	unsigned char cmd_sequence_no;
	unsigned char cmd;
	unsigned char payload_len;
	unsigned char payload[MAX_PAYLOAD_SIZE];
} msg_info;

//Azure state
typedef enum
{
	AZURE_DATA_PACKET = 1,	
	AZURE_POWERON_PACKET, 
	AZURE_HEART_BEAT_PACKET,
	AZURE_FOTA_REQUEST,
	AZURE_FOTA_ACK,
	AZURE_NO_PACKET
} e_azure_cmd;

//Request ID
typedef enum
{
	WIFI_SERVICE_REQID = 100,
	AZURE_SERVICE_REQID,
	WIFI_LED_SERVICE_REQID,
	INVALIDE_SERVICE_REQID
} e_service_ids;

/**
 * @brief This enum consist of all type of error code
 *
 */
typedef enum _status_code
{
	STATUS_SUCCESS,
	STATUS_ERROR,
	INVALID_JSON_RECEIVED,
	INVALID_JSON_TAG_VALUE_EMPTY,
	FOTA_CANCEL_FROM_REMOTE = -1, /* canceled by remote */
	FOTA_NO_SYNC = -2,
	FOTA_XMIT_ERROR = -4,
	FOTA_NACK = -5
} status_code;

/**
 * @brief This enum consist of all type of Services
 *
 */
typedef enum
{
	SERVICE_WIFI = 0,
	SERVICE_LED_CONTROL,
	SERVICE_HTTP_SERVER,
	SERVICE_SERIAL_COMM,
	SERVICE_DIAGNOSTIC,
	SERVICE_AZURE,
	/* Entry space of newly added services */
	SERVICE_INVALID
} all_services;

/**
 * @brief This enum consist of all type of Services
 *
 */
typedef enum _services_ids
{
	SERVICE_ID_WIFI = 0x01,
	SERVICE_ID_LED_CONTROL,
	SERVICE_ID_HTTP_SERVER,
	SERVICE_ID_SERIAL_COMM,
	SERVICE_ID_DIAGNOSTIC,
	SERVICE_ID_AZURE,
	SERVICE_ID_INVALID
} services_ids;


/**
 * @brief This enum consist of all type of Services
 *
 */
typedef enum _tx_service_stat
{
	TX_SEND_DATA_TO_MCU = 0x01,
	TX_SEND_WIFI_CONFIG_ACK,
	TX_SEND_ESP_RST_TO_MCU,
	TX_HOLD_STATE,
	TX_RESUME_HOLD_STATE,
	TX_SEND_CURRENT_TIME,
	TX_WAIT
} tx_service_stat;

/**
 * @brief This enum consist of all type of Services
 */
typedef enum _rx_service_stat
{
	RX_HOLD_STATE = 0x01,
	RX_RESUME_HOLD_STATE,
	RX_GET_COMMAND,
	RX_WAIT
} rx_service_stat;


/**
 * @brief This is the firmware version
 */
typedef struct _fw_version
{
	unsigned char major;
	unsigned char minor;
} fw_version;

extern fw_version _gst_mcu_ver, _gst_esp_ver;

/**
 * @brief This is enum for device type
 */
typedef enum  _e_device_type
{
	DEVICE_ID_ESP = 1,
	DEVICE_ID_MCU,
	DEVICE_ID_AZURE,
	DEVICE_INVALID_ID
} e_device_type;

/**
 * @brief This is the HTTP Info structure
 */
typedef struct _http_info
{
	unsigned char request_type;
	unsigned char content_type;
	unsigned char device_type;
	unsigned char web_server;
} http_info;

/**
 * @brief This is the web server enum
 */
typedef enum  _e_web_server
{
	WEB_SERVER_FOTA = 1,
	WEB_SERVER_AZURE,
	WEB_SERVER_INVALID_ID
} e_web_server;

/**
 * @brief This is the HTTP response enum
 */
typedef enum  _e_http_res
{
	RES_UPDATE_ESP_FOTA_STRING = 1,
	RES_UPDATE_MCU_FOTA_STRING,
	RES_UPDATE_CONNECTION_STRING,
	RES_INVALID_ID
} e_http_res;

/**
 * @brief This is the FOTA error code enum
 */
typedef enum _fota_error_code
{
	FOTA_GOING_TO_FOTA = 1001,
	FOTA_ALREADY_UPDATED,
	FOTA_CMD_ERROR,
	FOTA_INVALID_ERROR_CODE

} fota_error_code;

unsigned char comm_version_compare ( fw_version data1, fw_version data2) ;
unsigned char comm_get_wifi_status ( void );
int comm_get_service_state( int _u32ServiceID );
unsigned char comm_set_serial_number (char *serialNo_In);
char *comm_get_serial_number (void);
void comm_system_reboot( void );

#ifdef ENABLE_SERVICE_WIFI
extern QueueHandle_t g_wifi_control_req_queue;
#endif

#endif
