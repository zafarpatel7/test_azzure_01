#ifndef _JSON_H_
#define _JSON_H_

#include "cJSON.h"

int TestJSON(void);
unsigned char GetStringFromTag(char *pResponse, char *Output, char *TagIn);

#endif
