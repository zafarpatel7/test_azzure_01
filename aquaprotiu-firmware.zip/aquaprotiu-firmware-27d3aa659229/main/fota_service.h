#ifndef _FOTA_SERVICE_H_
#define _FOTA_SERVICE_H_


typedef enum _fota_recv_cmd
{
	FOTA_RECV_GOING_TO_BT = 0x100,
	FOTA_RECV_BT_READY,
	FOTA_RECV_WAIT_FOR_FOTA,
	FOTA_RECV_FLASH_ERASED,
	FOTA_RECV_WATTING_FOR_BIN,
	FOTA_RECV_BIN_UPDATED,
	FOTA_RECV_GOING_TO_APP

} fota_recv_cmd;

typedef struct _mcu_fota_header
{
	unsigned char product_name[18];
	unsigned char ver_major;
	unsigned char ver_minor;
	unsigned char CRC[2];
	unsigned char Sha256_info[64];
	unsigned char reserve[40];
	unsigned char header_crc[2]
} mcu_fota_header;

unsigned char start_MCU_IMG_download ( void );
unsigned char MCU_FOTA_Upgrade ( int MCU_img_size );
unsigned char start_ESP_IMG_download ( void );
void fota_service (void *pvParameter);
unsigned char validate_MCU_IMG_partition ( int parition_In );
int set_DownLoad_MCU_IMG_size( int mcuSize_In );
int get_BackupMCU_IMG_size( void );
int set_Backup_MCU_IMG_size( int mcuSize_In );
int get_MCU_IMG_size( void );
unsigned char fota_set_current_fota_stat (unsigned char _u8fotastat_In);
unsigned char fota_get_current_fota_stat( void );
unsigned char fota_update_fota_event ( e_fota_stat _u32fota_stat);
void fota_event_handler ( e_fota_stat _u32fota_stat );
int fota_mcu_response (fota_recv_cmd _cmdIn, unsigned short timeout);
unsigned char fota_MCU_End_comm ( void );
void fota_update_partition_status (void);

#endif
