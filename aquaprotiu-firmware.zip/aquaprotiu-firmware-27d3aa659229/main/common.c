#include "common.h"
#include "wifi_control.h"
#include "fota_service.h"
#include "flash.h"

fw_version _gst_mcu_ver, _gst_esp_ver;
int g_u32Delay = 1000;					/**< Delay for main thread endless loop */
int g_u32TaskSyncTime = (1000 / portTICK_PERIOD_MS);	/**< Delay for Task Sync Up endless loop */
char g_Serial_Number[16] = {0};
unsigned char g_MCU_powerOn = 0;

#define EXAMPLE_IOTHUB_CONNECTION_STRING CONFIG_IOTHUB_CONNECTION_STRING

char* _gu8ConnectoinString_primary = EXAMPLE_IOTHUB_CONNECTION_STRING;
char _gu8ConnectoinString[256] = {};

/* FreeRTOS event group to signal when we are connected & ready to start thread*/
EventGroupHandle_t g_xEventGroup = NULL;
EventGroupHandle_t g_xServiceStatEventGroup = NULL;
EventGroupHandle_t g_xSmartConfigEventGroup = NULL;

#ifdef ENABLE_SERVICE_WIFI
QueueHandle_t g_wifi_control_req_queue		= NULL;
#endif

/** @fn comm_get_wifi_status
 *
 * @brief This is used to get the current Wifi state
 *
 * @param
 *.
 *  @return current WIFI SERVICE STATE
 */
//NOTE : Only upgrade functionality are supported
unsigned char comm_version_compare ( fw_version data1, fw_version data2)
{
	unsigned char _u8local_result = STATUS_ERROR;

	printf ("INFO [COMM] : MINOR :  data1 : %d || data2 : %d \r\n",data1.minor,data2.minor);
	printf ("INFO [COMM] : MIJOR :  data1 : %d || data2 : %d \r\n",data1.major,data2.major);
	if ( data1.minor > data2.minor )
	{
		_u8local_result = STATUS_SUCCESS;

	} else if ( data1.major > data2.major ) {
		_u8local_result = STATUS_SUCCESS;
	}

	return _u8local_result;
}

/** @fn comm_get_wifi_status
 *
 * @brief This is used to get the current Wifi state
 *
 * @param
 *.
 *  @return current WIFI SERVICE STATE
 */
unsigned char comm_get_wifi_status ( void )
{
	return wifi_get_valid_stat();
}


/** @fn comm_get_service_state
 *
 * @brief This is used to get wifi the service state
 *
 * @param
 *
 * @return FOTA status
 */
int comm_get_service_state( int _u32ServiceID )
{
	int _u32local_state = 0;

	if (FOTA_SERVICE_BIT == _u32ServiceID)
	{
		_u32local_state = fota_get_current_fota_stat();

	} else if (WIFI_SERVICE_BIT == _u32ServiceID) {
		_u32local_state = wifi_get_valid_stat();

	}

	return _u32local_state;
}


/** @fn comm_get_serial_number 
 *
 * @brief This is used to get the serial number of the board
 *
 * @param
 *.
 *  @return STATUS_SUCCESS 
 */
char *comm_get_serial_number (void)
{
	return (char *)g_Serial_Number;
}


/** @fn comm_set_serial_number 
 *
 * @brief This is used to set the serial number of the board
 *
 * @param
 *.
 *  @return STATUS_SUCCESS 
 */
unsigned char comm_set_serial_number (char *serialNo_In)
{
	unsigned char _u8local_result = STATUS_ERROR;

	if (serialNo_In != NULL)
	{
		nvm_set_string (DEVICE_SERIAL_NUM, serialNo_In);
		strcpy (g_Serial_Number, serialNo_In);
		_u8local_result = STATUS_SUCCESS;
	}

	return _u8local_result;
}


/**
 *
 * @brief This function used to soft reboot the system
 *
 * @return NA
 */
void comm_system_reboot( void )
{
	//TODO : Call system reboot function here
    esp_restart();

}
