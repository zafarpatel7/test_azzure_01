#ifndef _HTTP_SERVICES_H_
#define _HTTP_SERVICES_H_

extern char g_esp_fota_download[256];
extern char g_mcu_fota_download[256];

unsigned char http_send_query_get_resp( http_info _st_httpInfo_In );
unsigned char test ( void );
unsigned char http_perform_web_url (unsigned char _u8device_In);
unsigned char http_process_response (unsigned char _u8RespTag_In);
unsigned char http_perform_request ( http_info _st_httpInfo_In );
unsigned char http_perform_post_data ( void );

#endif
