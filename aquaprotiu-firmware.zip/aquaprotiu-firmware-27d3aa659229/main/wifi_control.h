#ifndef _WIFI_CONTROL_H_
#define _WIFI_CONTROL_H_

/*------ Declare macros here ------------------------------------------------*/
#define WIFI_SERVICE_RXQ_TIMEOUT 			100   /*The maximum amount of time the task
											should block waiting for an item
											to receive */

#define SMART_WIFI_CONNECTED 		       		( 1 << 0 )
#define SMART_WIFI_DISCONNECT  					( 1 << 1 )
#define SMART_SMARTCONFIG_DONE     				( 1 << 2 )

void wifi_stat_change (e_wifi_state_type _u8Stat_In);
unsigned char get_wifi_config( void );
void wifi_control_service(void *param);
void wifi_smart_config_service (void * parm);
unsigned char wifi_get_valid_stat ( void );
void wifi_set_valid_stat ( unsigned char _u8stat_In );

#endif
