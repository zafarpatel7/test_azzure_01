#include "common.h"
#include "led_control.h"
#include "flash.h"
#include "http_services.h"
#include "fota_service.h"
#include "rom/crc.h"

/**** Define ****************/
#define FOTA_NUMBER_OF_PARTITION (4)
#define MCU_BACKUP_1 "mcu_img1"
#define MCU_BACKUP_2 "mcu_img2"
#define BUFFSIZE 1024
#define HASH_LEN 32 /* SHA-256 digest length */
#define MCU_FOTA_SERVER_URL CONFIG_MCU_FOTA_STRING
#define ESP_FOTA_SERVER_URL CONFIG_ESP_FOTA_STRING
#define MCU_IMG_PARTITION (1)//CONFIG_MCU_IMG_PARTITION
#define MAX_RETRY_COUNT (2)
#define HEADER_VALIDATION (0)
/***********************************************************************************************************************
 * Character constants
 **********************************************************************************************************************/
#define SOH   0x01
#define STX   0x02
#define EOT   0x04
#define ACK   0x06
#define NAK   0x15
#define CAN   0x18
#define CTRLZ 0x1A
#define DLY_1S 1000
#define MAXRETRANS 25
#define FOTA_MCU_UPGRADE_RETRY_COUNT (16)
#ifdef XMODEM_1K
/* 1024 for XModem 1k + 3 head chars + 2 crc */
#define FOTA_MCU_XMODEM_PAYLOAD_SIZE (1024 + 3 + 2)
#else
/* 128 for XModem + 3 head chars + 2 crc */
#define FOTA_MCU_XMODEM_PAYLOAD_SIZE (128 + 3 + 2)
#endif

/****** All globle variabl ***********/
static char ota_write_data[BUFFSIZE + 1] = { 0 };
int _gu32ErrorCode;
char gMcuImgSize[32] = {0};
char gPartitionName[32] = {0};
bool gSendMCUFirm = false;
int gSendMCUFirmLen = 0, gu32ImageSize = 0;
unsigned char _gu8BothFOTAFlag = 0, gFOTARetryCount = 0, gTryBackupImg = 0;
int _g32mcuFotaCount = 0;
static const char *FOTA_TASK_TAG = "_FOTA_";
unsigned char g_fota_service_stat = 0;
static void http_cleanup(esp_http_client_handle_t client);
mcu_fota_header mcu_fota_info;


/********** All extern variable *******/
extern const uint8_t server_cert_pem_start[] asm("_binary_ca_cert_pem_start");
extern const uint8_t server_cert_pem_end[] asm("_binary_ca_cert_pem_end");


/* CRC16 implementation acording to CCITT standards */
static const unsigned short _gu16_crc16tab[256]= {
	0x0000,0x1021,0x2042,0x3063,0x4084,0x50a5,0x60c6,0x70e7,
	0x8108,0x9129,0xa14a,0xb16b,0xc18c,0xd1ad,0xe1ce,0xf1ef,
	0x1231,0x0210,0x3273,0x2252,0x52b5,0x4294,0x72f7,0x62d6,
	0x9339,0x8318,0xb37b,0xa35a,0xd3bd,0xc39c,0xf3ff,0xe3de,
	0x2462,0x3443,0x0420,0x1401,0x64e6,0x74c7,0x44a4,0x5485,
	0xa56a,0xb54b,0x8528,0x9509,0xe5ee,0xf5cf,0xc5ac,0xd58d,
	0x3653,0x2672,0x1611,0x0630,0x76d7,0x66f6,0x5695,0x46b4,
	0xb75b,0xa77a,0x9719,0x8738,0xf7df,0xe7fe,0xd79d,0xc7bc,
	0x48c4,0x58e5,0x6886,0x78a7,0x0840,0x1861,0x2802,0x3823,
	0xc9cc,0xd9ed,0xe98e,0xf9af,0x8948,0x9969,0xa90a,0xb92b,
	0x5af5,0x4ad4,0x7ab7,0x6a96,0x1a71,0x0a50,0x3a33,0x2a12,
	0xdbfd,0xcbdc,0xfbbf,0xeb9e,0x9b79,0x8b58,0xbb3b,0xab1a,
	0x6ca6,0x7c87,0x4ce4,0x5cc5,0x2c22,0x3c03,0x0c60,0x1c41,
	0xedae,0xfd8f,0xcdec,0xddcd,0xad2a,0xbd0b,0x8d68,0x9d49,
	0x7e97,0x6eb6,0x5ed5,0x4ef4,0x3e13,0x2e32,0x1e51,0x0e70,
	0xff9f,0xefbe,0xdfdd,0xcffc,0xbf1b,0xaf3a,0x9f59,0x8f78,
	0x9188,0x81a9,0xb1ca,0xa1eb,0xd10c,0xc12d,0xf14e,0xe16f,
	0x1080,0x00a1,0x30c2,0x20e3,0x5004,0x4025,0x7046,0x6067,
	0x83b9,0x9398,0xa3fb,0xb3da,0xc33d,0xd31c,0xe37f,0xf35e,
	0x02b1,0x1290,0x22f3,0x32d2,0x4235,0x5214,0x6277,0x7256,
	0xb5ea,0xa5cb,0x95a8,0x8589,0xf56e,0xe54f,0xd52c,0xc50d,
	0x34e2,0x24c3,0x14a0,0x0481,0x7466,0x6447,0x5424,0x4405,
	0xa7db,0xb7fa,0x8799,0x97b8,0xe75f,0xf77e,0xc71d,0xd73c,
	0x26d3,0x36f2,0x0691,0x16b0,0x6657,0x7676,0x4615,0x5634,
	0xd94c,0xc96d,0xf90e,0xe92f,0x99c8,0x89e9,0xb98a,0xa9ab,
	0x5844,0x4865,0x7806,0x6827,0x18c0,0x08e1,0x3882,0x28a3,
	0xcb7d,0xdb5c,0xeb3f,0xfb1e,0x8bf9,0x9bd8,0xabbb,0xbb9a,
	0x4a75,0x5a54,0x6a37,0x7a16,0x0af1,0x1ad0,0x2ab3,0x3a92,
	0xfd2e,0xed0f,0xdd6c,0xcd4d,0xbdaa,0xad8b,0x9de8,0x8dc9,
	0x7c26,0x6c07,0x5c64,0x4c45,0x3ca2,0x2c83,0x1ce0,0x0cc1,
	0xef1f,0xff3e,0xcf5d,0xdf7c,0xaf9b,0xbfba,0x8fd9,0x9ff8,
	0x6e17,0x7e36,0x4e55,0x5e74,0x2e93,0x3eb2,0x0ed1,0x1ef0
};

/** @fn fota_crc16_ccitt
 *
 * @brief This function used to calculate crc
 *
 *  @return CRC value 
 */
unsigned short fota_crc16_ccitt(const void *buf, int _u32len_In)
{
	register int _u32counter;
	register unsigned short _u16local_crc = 0;

	for( _u32counter = 0; _u32counter < _u32len_In; _u32counter++)
		_u16local_crc = (_u16local_crc<<8) ^ _gu16_crc16tab[((_u16local_crc>>8) ^ *(char *)buf++)&0x00FF];

	return _u16local_crc;
}

/** @fn sendData
 *
 * @brief This function used to send data on UART through TX Thread
 *
 * @param logName : Used for log taging
 * @param data  : Data which we need to send
 *.
 *  @return Number of bytes transmitted on UART
 */
int fota_data_send(const char* logName, const char* data)
{
    const int len = strlen(data);
    const int txBytes = uart_write_bytes(UART_NUM_1, data, len);
    ESP_LOGI(logName, "Wrote %d bytes", txBytes);
    return txBytes;
}


/** @fn fota_crc16_ccitt
 *
 * @brief This function used to send signle byte on TX
 *
 *  @return buty 
 */
int fota_data_send_byte (char _u8Byte)
{
	const int txBytes = uart_write_bytes(UART_NUM_1, &_u8Byte, sizeof(_u8Byte));
//	ESP_LOGI(FOTA_TASK_TAG, "Wrote %d bytes", txBytes);
	return txBytes;
}


/** @fn fota_data_send_buff 
 *
 * @brief This function used to calculate crc
 *
 *  @return number of byte
 */
int fota_data_send_buff (char* _u8Buff, int len)
{
	const int txBytes = uart_write_bytes(UART_NUM_1, _u8Buff, len);
//	ESP_LOGI(FOTA_TASK_TAG, "Wrote %d bytes", txBytes);
	return txBytes;
}


/** @fn fota_mcu_response 
 *
 * @brief This function used to read the MCU response
 *
 * @return N.A. 
 */
int fota_mcu_response (fota_recv_cmd _cmdIn, unsigned short timeout) // msec timeout
{
#if 1
	int delay = (timeout / 1000);
	int rxBytes;
	char *plocal = NULL;
	char _u8local_buff[32] = {0}, _u8local_Result = STATUS_ERROR;

	memset(_u8local_buff, '\0', sizeof(_u8local_buff));

	while(delay)
	{
		rxBytes = uart_read_bytes(UART_NUM_1, (unsigned char*)&_u8local_buff, sizeof(_u8local_buff), 1000 / portTICK_RATE_MS);
		if (rxBytes <= 0)
		{
			--delay;
			if(delay)
			{
				continue;
			}
		} else {
			switch (_cmdIn)
			{
				case FOTA_RECV_GOING_TO_BT:
					plocal = strstr(_u8local_buff, "GOING_TO_BT#");
					printf (" FOTA_RECV_GOING_TO_BT INFO :: %s\r\n",_u8local_buff);
					if (plocal != NULL){
						_u8local_Result = STATUS_SUCCESS;
					}
					break;
				case FOTA_RECV_BT_READY:
					plocal = strstr(_u8local_buff, "_READY#");
					printf (" FOTA_RECV_BT_READY INFO :: %s\r\n",_u8local_buff);
					if (plocal != NULL){
						_u8local_Result = STATUS_SUCCESS;
						printf("<<<<<<<<<  SUCCESS >>>>>>\r\n");
					}else{
						printf("<<<<<<<<<  FAIL >>>>>>\r\n");
					}
					break;
				case FOTA_RECV_WAIT_FOR_FOTA:
					plocal = strstr(_u8local_buff, "WAITING_FOR_FOTA#");
					printf ("FOTA_RECV_WAIT_FOR_FOTA INFO :: %s\r\n",_u8local_buff);
					if (plocal != NULL)
						_u8local_Result = STATUS_SUCCESS;

					break;
				case FOTA_RECV_FLASH_ERASED:
					plocal = strstr(_u8local_buff, "FLASH_ERASED#");
					printf ("FOTA_RECV_FLASH_ERASED INFO :: %s\r\n",_u8local_buff);
					if (plocal != NULL)
						_u8local_Result = STATUS_SUCCESS;

					break;
				case FOTA_RECV_WATTING_FOR_BIN:
					plocal = strstr(_u8local_buff, "WAITING_FOR_BIN#");
					printf (" FOTA_RECV_WATTING_FOR_BIN INFO :: %s\r\n",_u8local_buff);
					if (plocal != NULL)
						_u8local_Result = STATUS_SUCCESS;

					break;
				case FOTA_RECV_BIN_UPDATED:
					plocal = strstr(_u8local_buff, "BIN_UPDATED#");
					printf (" FOTA_RECV_BIN_UPDATED INFO :: %s\r\n",_u8local_buff);
					if (plocal != NULL)
						_u8local_Result = STATUS_SUCCESS;

					break;
				case FOTA_RECV_GOING_TO_APP:
					plocal = strstr(_u8local_buff, "GOING_TO_APP#");
					printf ("FOTA_RECV_GOING_TO_APP INFO :: %s\r\n",_u8local_buff);
					if (plocal != NULL)
						_u8local_Result = STATUS_SUCCESS;

					break;
				default:
					_u8local_Result = STATUS_ERROR;
					break;
			}
			break;
		}
	}
#endif
	printf ("END INFO :: %s :: %d \r\n",_u8local_buff,_u8local_Result);
	return _u8local_Result;
}


/** @fn fota_data_received
 *
 * @brief This function used to received response from MCU
 *
 * @return N.A. 
 */
int fota_data_received(unsigned short timeout) // msec timeout
{
	int delay = 100;
	int rxBytes;
	unsigned short _u16local_rx = 0;
	int length = 0;

	while(delay)
	{
		ESP_ERROR_CHECK(uart_get_buffered_data_len(UART_NUM_1, (size_t*)&length));
		if (length != 0)
		{
			rxBytes = uart_read_bytes(UART_NUM_1, &_u16local_rx, length, 10);
			if (rxBytes > 0)
			{
				uart_flush(UART_NUM_1);
				break;
			}
			printf("<<< Returen -2 [%d]>>>>\n", _u16local_rx);
			return -2;
		} else {
			--delay;
			if(delay)
			{
				vTaskDelay(10 / portTICK_PERIOD_MS);
				continue;
			}
		}
	}

	printf ("INFO :: %d\r\n",_u16local_rx);
	return (_u16local_rx & 0x0FF);
}

/** @fn fota_event_handler
 *
 * @brief This function used to update the FOTA event
 *
 * @return N.A. 
 */
void fota_event_handler ( e_fota_stat _u32fota_stat )
{
	g_fota_service_stat = _u32fota_stat;
}


/** @fn fota_update_fota_event 
 *
 * @brief This function used to update the FOTA event
 *
 * @return SUCCESS or ERROR
 */
unsigned char fota_update_fota_event ( e_fota_stat _u32fota_stat )
{
	unsigned char _u8local_result = 0;

	if ( g_fota_service_stat != FOTA_WAIT )
	{
		_u8local_result = STATUS_ERROR;
	}
	else
	{
		fota_event_handler (_u32fota_stat);
		_u8local_result = STATUS_SUCCESS;
	}

	return _u8local_result;
}

/** @fn fota_set_current_fota_stat 
 *
 * @brief This function used to set the current FOTA state
 *
 * @return SUCCESS or ERROR
 */
unsigned char fota_set_current_fota_stat (unsigned char _u8fotastat_In)
{
	printf ("@@@ IN : %d ****** Present : %d @@@\r\n", _u8fotastat_In, g_fota_service_stat);
	if ( g_fota_service_stat == FOTA_ESP_START || g_fota_service_stat == FOTA_MCU_START )
	{
		return FAIL;
	}
	else
	{
		g_fota_service_stat = _u8fotastat_In;
	}
	return STATUS_SUCCESS;
}

/** @fn fota_get_current_fota_stat
 *
 * @brief This function used to get the current FOTA state
 *
 * @return SUCCESS or ERROR
 */
unsigned char fota_get_current_fota_stat( void )
{
	return g_fota_service_stat;
}


//Get MCU IMG Size from NVS flash
int get_DownLoadMCU_IMG_size( void )
{
	int lImageSize = 0;

	nvm_get_string (MCU_DOWNLOAD_IMG_SIZE, gMcuImgSize);

	if (strlen(gMcuImgSize) > 0)
	{
		lImageSize = atoi(gMcuImgSize);
	}

	return lImageSize;
}

//Get MCU IMG Size from NVS flash
int get_BackupMCU_IMG_size( void )
{
	int lImageSize = 0;

	nvm_get_string (MCU_BACKUP_SIZE, gMcuImgSize);

	if (strlen(gMcuImgSize) > 0)
	{
		lImageSize = atoi(gMcuImgSize);
	}

	return lImageSize;
}

//Set MCU IMG Size from NVS flash
int set_DownLoad_MCU_IMG_size( int mcuSize_In )
{
	char lBuff[32] = {0};

	sprintf(lBuff, "%d", mcuSize_In);

	//Erase this sector first or not ?
	nvm_erase_string (MCU_DOWNLOAD_IMG_SIZE, NULL);

	//Set input size
	nvm_set_string (MCU_DOWNLOAD_IMG_SIZE, lBuff);


	return STATUS_SUCCESS;
}

//Set MCU IMG Size from NVS flash
int set_Backup_MCU_IMG_size( int mcuSize_In )
{
	char lBuff[32] = {0};

	sprintf(lBuff, "%d", mcuSize_In);

	//Erase this sector first or not ?
	nvm_erase_string (MCU_BACKUP_SIZE, NULL);

	//Set input size
	nvm_set_string (MCU_BACKUP_SIZE, lBuff);


	return STATUS_SUCCESS;
}

static void http_cleanup(esp_http_client_handle_t client)
{
    esp_http_client_close(client);
    esp_http_client_cleanup(client);
}


//NOTE : Not in used 
unsigned char validate_MCU_IMG_partition ( int parition_In )
{
	return STATUS_SUCCESS;
}


unsigned short fota_crc_calculate (char *Buff, int len)
{
	unsigned short crc = 0;

	if (Buff != NULL)
	{
		printf ("BUff :: %s [Len : %d] \r\n",Buff,len);

		crc = ~crc16_be((uint16_t)~0xffff, (uint8_t*)Buff, len);

		printf ("CRC in be : %x \r\n",crc);
	}

	return crc;
}


uint16_t firmware_crc_calculate (uint16_t crc_in, char *Buff, int len)
{
	uint16_t crc = 0;
	uint16_t init = 0;

	if (crc_in == 0) {

		init = ~0xffffffff;
	} else {

		init = crc_in;
	}

	if (Buff != NULL)
	{
//		printf ("BUff :: %s [Len : %d | %x] \r\n",Buff,len, init);

		crc = crc16_be((uint16_t)init, (uint8_t*)Buff, len);

		printf ("CRC in be : %x || (%x) \r\n",crc ,~crc);
	}

	return crc;
}

/** @fn start_MCU_IMG_download
 *
 * @brief This function used to download MCU Firmware in ESP partition
 *
 * @param N.A.
 *.
 *  @return None.(Will not Return from here.)
 */
unsigned char start_MCU_IMG_download ( void )
{
	esp_err_t err;
	esp_ota_handle_t update_handle = 0 ;
	const esp_partition_t *update_partition = NULL;
	int binary_file_length = 0;
	bool image_header_was_checked = false;
	unsigned char uFOTACompleted = STATUS_SUCCESS;
	esp_http_client_handle_t client = NULL;
	size_t read_offset = 0;
	unsigned short crc_value = 0;
	unsigned char start_byte = 0;
	unsigned short mcu_firmware_crc = 0;


	//Check Partition name
	//Read partition information
	nvm_get_string ( MCU_DOWNLOAD_IMG, gPartitionName);

	printf ("Downloading into : %s\n", gPartitionName);
	//If partition name not present
	if ( strlen(gPartitionName) <= 0 )
	{
		//Update New Partition
		strcpy( gPartitionName, MCU_BACKUP_1);
		nvm_set_string ( MCU_DOWNLOAD_IMG, gPartitionName); //Update New Partition

	} else {
		//If partition name found
		if (0 == ((0 == strcmp(gPartitionName, MCU_BACKUP_1)) || (0 == strcmp(gPartitionName, MCU_BACKUP_2))))
		{
			//If wrong partition name
			strcpy( gPartitionName, MCU_BACKUP_1);
			nvm_set_string ( MCU_DOWNLOAD_IMG, gPartitionName); //Update New Partition
		}
	}

	printf (" <<<<<<< Partition Name : %s >>>>>>>> \n",gPartitionName);

	do
	{
		ESP_LOGI(FOTA_TASK_TAG, "Starting MCU OTA ...");

#if 1	
		///@harshal : Get the partition details
		update_partition = esp_partition_find_first(ESP_PARTITION_TYPE_APP , ESP_PARTITION_SUBTYPE_APP_OTA_2 , gPartitionName);

		if ( update_partition == NULL )
		{
			update_partition = esp_partition_find_first(ESP_PARTITION_TYPE_APP , ESP_PARTITION_SUBTYPE_APP_OTA_3 , gPartitionName);
			if ( update_partition == NULL )
			{
				uFOTACompleted = FAIL;
				break;
			}
		}

		ESP_LOGI(FOTA_TASK_TAG, "Writing to partition subtype %d at offset 0x%x",
				update_partition->subtype, update_partition->address);

		//If Partition is invalid
		if ( STATUS_SUCCESS != validate_MCU_IMG_partition ( MCU_IMG_PARTITION ) )
		{
			uFOTACompleted = FAIL;
			break;
		}		

		esp_http_client_config_t config = {
			.timeout_ms = CONFIG_OTA_RECV_TIMEOUT,
		};

		config.url = (char *)&g_mcu_fota_download;
#ifdef CONFIG_SKIP_COMMON_NAME_CHECK
		config.skip_cert_common_name_check = true;
#endif

		//Http Initialize with latest configuration
		client = esp_http_client_init ( &config );
		if (client == NULL) {
			ESP_LOGE(FOTA_TASK_TAG, "Failed to initialise HTTP connection");
			uFOTACompleted = FAIL;
			break;
		}

		//Open http client handle
		err = esp_http_client_open ( client, 0 );
		if (err != ESP_OK) {
			ESP_LOGE(FOTA_TASK_TAG, "Failed to open HTTP connection: %s", esp_err_to_name(err));
			esp_http_client_cleanup(client);
			uFOTACompleted = FAIL;
			break;
		}

		esp_http_client_fetch_headers ( client );

		/*deal with all receive packet*/	
		while (1) 
		{
			int data_read = esp_http_client_read(client, ota_write_data, BUFFSIZE);

			if (data_read < 0) 
			{
				ESP_LOGE(FOTA_TASK_TAG, "Error: SSL data read error");
				uFOTACompleted = FAIL;
				break;

			} else if (data_read > 0) {

				esp_app_desc_t new_app_info;
				if (image_header_was_checked == false)
				{
#if HEADER_VALIDATION
					if (data_read > sizeof(mcu_fota_header))
					{
						memset (&mcu_fota_info, '\0', sizeof(mcu_fota_info));
						ESP_LOGI(FOTA_TASK_TAG, ">> Size of Header : [ %d ]", sizeof(mcu_fota_info));
						// check current version with downloading
						memcpy(&mcu_fota_info, &ota_write_data[0], sizeof(mcu_fota_info));
						ESP_LOGI(FOTA_TASK_TAG, ">> Product Name : [ %s ]", mcu_fota_info.product_name);
						ESP_LOGI(FOTA_TASK_TAG, ">> MCU firmware version: [ %d:%d ]", mcu_fota_info.ver_major, mcu_fota_info.ver_minor);
						ESP_LOGI(FOTA_TASK_TAG, ">> CRC Value : [%x:%x]", mcu_fota_info.CRC[0], mcu_fota_info.CRC[1] );
						ESP_LOGI(FOTA_TASK_TAG, ">> Header CRC : [ %x:%x ]", mcu_fota_info.header_crc[0], mcu_fota_info.header_crc[1]);

						//Calculate Header CRC
						crc_value = fota_crc_calculate ( &ota_write_data[0], (sizeof(mcu_fota_info) - 2) );
						ESP_LOGI(FOTA_TASK_TAG, ">> Header CRC Be : [ %x : %x ]", ((crc_value >> 8) & 0xFF), (crc_value & 0x00FF));

						//Validate Header CRC
						if ((mcu_fota_info.header_crc[0] != ((crc_value>>8) & 0xFF)) || (mcu_fota_info.header_crc[1] != (crc_value & 0x00FF)))
						{
							ESP_LOGE(FOTA_TASK_TAG, "MCU firmware header CRC not match");
							uFOTACompleted = FAIL;
							break;
						}

						image_header_was_checked = true;

						err = esp_ota_begin(update_partition, OTA_SIZE_UNKNOWN, &update_handle);
						if (err != ESP_OK) {
							ESP_LOGE(FOTA_TASK_TAG, "esp_ota_begin failed (%s)", esp_err_to_name(err));
							uFOTACompleted = FAIL;
							break;
						}
						start_byte = sizeof(mcu_fota_info);
						data_read = data_read - start_byte;
						mcu_firmware_crc = 0;
						ESP_LOGI(FOTA_TASK_TAG, "esp_ota_begin succeeded");
					} else {
						ESP_LOGE(FOTA_TASK_TAG, "received package is not fit len");
						uFOTACompleted = FAIL;
						break;
					}
#else
					if (image_header_was_checked == false)
					{
						image_header_was_checked = true;

						err = esp_ota_begin(update_partition, OTA_SIZE_UNKNOWN, &update_handle);
						if (err != ESP_OK) {
							ESP_LOGE(FOTA_TASK_TAG, "esp_ota_begin failed (%s)", esp_err_to_name(err));
							uFOTACompleted = FAIL;
							break;
						}
						ESP_LOGI(FOTA_TASK_TAG, "esp_ota_begin succeeded");
					}
#endif
				}

#if HEADER_VALIDATION
				mcu_firmware_crc = firmware_crc_calculate ( mcu_firmware_crc, &ota_write_data[start_byte], data_read );
#endif
				err = esp_mcu_ota_write ( update_handle, (const void *)&ota_write_data[start_byte], data_read );

				if ( err != ESP_OK ) 
				{
					uFOTACompleted = FAIL;
					break;
				}

				binary_file_length += data_read;
				start_byte = 0;
				ESP_LOGD(FOTA_TASK_TAG, "Written image length %d | Offset : %d", binary_file_length, read_offset);

			} else if ( data_read == 0 ) {

				if ( errno == ECONNRESET || errno == ENOTCONN ) 
				{
					ESP_LOGE(FOTA_TASK_TAG, "Connection closed, errno = %d", errno);
					break;
				}

				if (esp_http_client_is_complete_data_received(client) == true) 
				{
					ESP_LOGI(FOTA_TASK_TAG, "Connection closed");
					break;
				}
			}
		}

		ESP_LOGI(FOTA_TASK_TAG, "Total Write binary data length: %d", binary_file_length);
#if HEADER_VALIDATION
		mcu_firmware_crc = ~(mcu_firmware_crc);

		ESP_LOGI(FOTA_TASK_TAG, "Firmware CRC : %x", mcu_firmware_crc);

		//Validate Header CRC
		if ((mcu_fota_info.CRC[0] != ((mcu_firmware_crc>>8) & 0xFF)) || (mcu_fota_info.CRC[1] != (mcu_firmware_crc & 0x00FF)))
		{
			ESP_LOGE(FOTA_TASK_TAG, "MCU firmware not match");
			uFOTACompleted = FAIL;
			break;
		}
#endif
		if ( uFOTACompleted == STATUS_SUCCESS)
		{
			if ( esp_http_client_is_complete_data_received(client) != true ) 
			{
				ESP_LOGE(FOTA_TASK_TAG, "Error in receiving complete file");
				uFOTACompleted = FAIL;
				break;
			}
		}

		err = esp_mcu_ota_end(update_handle);
		if (err != ESP_OK) 
		{
			if (err == ESP_ERR_OTA_VALIDATE_FAILED) 
			{
				ESP_LOGE(FOTA_TASK_TAG, "Image validation failed, image is corrupted");
			}

			ESP_LOGE(FOTA_TASK_TAG, "esp_ota_end failed (%s)!", esp_err_to_name(err));
			uFOTACompleted = FAIL;
			break;
		}
#endif
	} while (0);

	http_cleanup(client);

	//Write into NVS memory
	if(uFOTACompleted == STATUS_SUCCESS)
	{
		set_DownLoad_MCU_IMG_size(binary_file_length);
	}

	//Clear MCU FOTA request
	//NOTE : Have to check this is required or not
	memset(&g_mcu_fota_download, '\0', sizeof(g_mcu_fota_download));

	return uFOTACompleted;
}

/** @fn MCU_FOTA_Upgrade
 *
 * @brief This function used to upgrade MCU FOTA
 *
 * @param N.A.
 *.
 *  @return None.(Will not Return from here.)
 */
unsigned char MCU_FOTA_Upgrade ( int MCU_img_size )
{
	esp_err_t err;
	size_t read_offset = 0;
	const esp_partition_t *mcu_partition = NULL;
	int binary_file_length = 0;
	unsigned char uUpgradeCompleted = STATUS_SUCCESS;
	unsigned char ucRetry = 0;
	unsigned char lPartitionFound = 0;
	unsigned char _u8xbuff[FOTA_MCU_XMODEM_PAYLOAD_SIZE]; /* 1024 for XModem 1k + 3 head chars + 2 crc + nul */
	int _u32bufsz, _u16local_crc = -1;
	unsigned char _u8packetno = 1;
	int _u32Itr, _u32result, _u32len_In = 0;
	int _u32local_retry;
	unsigned short ccrc;
	unsigned char _u8ccks;

	printf ("Uploading From : %s\n", gPartitionName);

	do
	{
		if ( strlen(gPartitionName) <= 0 )
		{
			uUpgradeCompleted = STATUS_ERROR;
			break;
		}

		//Find MCU Image partition
		for ( ucRetry = 0; ucRetry < FOTA_NUMBER_OF_PARTITION; ucRetry++ )
		{
			mcu_partition = esp_ota_get_next_update_partition( mcu_partition );	
			if ( mcu_partition == NULL)
			{
				uUpgradeCompleted = STATUS_ERROR;
				break;
			}

			ESP_LOGI(FOTA_TASK_TAG, "Writing to partition subtype %d at offset 0x%x %s", 
					mcu_partition->subtype, mcu_partition->address, mcu_partition->label);

			if ( strcmp((const char *)mcu_partition->label, (const char*)gPartitionName) == 0)
			{
				lPartitionFound = 1;
				ESP_LOGI(FOTA_TASK_TAG, "MCU_IMG Partition found in WIFI OTA Process");
				break;
			}
			else
			{
				ESP_LOGI(FOTA_TASK_TAG, "MCU FOTA Partition : %s", mcu_partition->label);
				continue;
			}
		}

		if ( ( mcu_partition == NULL ) || ( 0 == lPartitionFound ) )
		{
			uUpgradeCompleted = STATUS_ERROR;
			break;
		}	

		//Read MCU flash size which we maintain into NVM
		if ( MCU_img_size <= BUFFSIZE )
		{
			uUpgradeCompleted = STATUS_ERROR;
			break;
		}


		ESP_LOGE(FOTA_TASK_TAG, " MCU image size ( %d ) >>>>>>> ", MCU_img_size);

		//Set default offset value for MCU flash
		read_offset = 0;

		printf ("***************** Waiting for Continue  **********\r\n");

		for(;;)
		{
			for( _u32local_retry = 0; _u32local_retry < FOTA_MCU_UPGRADE_RETRY_COUNT; ++_u32local_retry)
			{
				if ((_u32result = fota_data_received((DLY_1S)<<1)) >= 0)
				{
					switch (_u32result)
					{
						case 'C':
							_u16local_crc = 1;
							goto start_trans;
						case NAK:
							_u16local_crc = 0;
							goto start_trans;
						case CAN:
							if ((_u32result = fota_data_received(DLY_1S)) == CAN) {
								fota_data_send_byte(ACK);
								return FOTA_CANCEL_FROM_REMOTE; /* canceled by remote */
							}
							printf ("***************** Firmware upgrade cancel from MCU - 1  **********\r\n");
							break;
						default:
							break;
					}
				}
			}
			fota_data_send_byte(CAN);
			fota_data_send_byte(CAN);
			fota_data_send_byte(CAN);
			printf ("***************** Firmware upgrade cancel from MCU 3  **********\r\n");
			return FOTA_NO_SYNC; /* no sync */

			printf ("***************** Binary sharing started  **********\r\n");
start_trans:
			_u8xbuff[0] = SOH;		//Start of frame
			_u32bufsz = 128;		//buffer size
			_u8xbuff[1] = _u8packetno;	//Packet Number
			_u8xbuff[2] = ~_u8packetno;	//Inverted Packet Number

			_u32result = (MCU_img_size - _u32len_In);

			printf ("INFO remain data :: %d\r\n",_u32result);

			if (_u32result > _u32bufsz)	//If remain bytes is greater then total sent bytes
				_u32result = _u32bufsz;	//Then allocate Remain byte qual to total sent bytes

			if (_u32result >= 0)
			{
				memset (&_u8xbuff[3], 0, _u32bufsz); //Clear all payload data

				if (_u32result == 0)
				{
					_u8xbuff[3] = CTRLZ; //If Remain Byte equal to "0" then exit
				}
				else
				{
					err = esp_partition_read(mcu_partition, read_offset, &_u8xbuff[3], _u32result);

					if (err != ESP_OK)
					{
						ESP_LOGE(FOTA_TASK_TAG, "esp_partition_read failed (%s)", esp_err_to_name(err));
						uUpgradeCompleted = STATUS_ERROR;
						break;
					}

					binary_file_length += _u32result;	//Total read partition size
					read_offset += _u32result;	//Update offset value

					if (_u32result < _u32bufsz)
						//If Read Bytes is less then 128 then add "CTRLZ" at the end of all bytes
						_u8xbuff[3+_u32result] = CTRLZ;
				}

				if (_u16local_crc)
				{
					//Calculate CRC for Payload and update into Tx buffer
					ccrc = fota_crc16_ccitt(&_u8xbuff[3], _u32bufsz);
					_u8xbuff[_u32bufsz+3] = (ccrc>>8) & 0xFF;
					_u8xbuff[_u32bufsz+4] = ccrc & 0xFF;

					printf("INFO : Calculated CRC [%02x | %02x] \r\n",_u8xbuff[_u32bufsz+3],_u8xbuff[_u32bufsz+4]);
				}
				else
				{
					//If CRC is zero
					_u8ccks = 0;
					for (_u32Itr = 3; _u32Itr < _u32bufsz+3; ++_u32Itr) {
						_u8ccks += _u8xbuff[_u32Itr];
					}
					_u8xbuff[_u32bufsz+3] = _u8ccks;
				}

				for (_u32local_retry = 0; _u32local_retry < MAXRETRANS; ++_u32local_retry)
				{
					for (_u32Itr = 0; _u32Itr < (_u32bufsz+4 + (_u16local_crc ? 1:0)); ++_u32Itr)
					{
						//Send complete buffer with CRC to the MCU
						uart_write_bytes(UART_NUM_1, (char *)&_u8xbuff[_u32Itr], sizeof(char));
					}

					printf("INFO : Wait for respose : %d \r\n",_u32Itr);

					//Wait for response from MCU for 1 Sec
					if ((_u32result = fota_data_received(DLY_1S)) >= 0 )
					{
						switch (_u32result)
						{
							case ACK:
								++_u8packetno;
								_u32len_In += _u32bufsz;
								goto start_trans;
							case CAN:
								if ((_u32result = fota_data_received(DLY_1S)) == CAN) {
									fota_data_send_byte(ACK);
									return FOTA_CANCEL_FROM_REMOTE; /* canceled by remote */
								}
								break;
							case NAK:
							default:
								break;
						}
					}
				}
				fota_data_send_byte(CAN);
				fota_data_send_byte(CAN);
				fota_data_send_byte(CAN);
				return FOTA_XMIT_ERROR; /* xmit error */
			}
			else
			{
				for (_u32local_retry = 0; _u32local_retry < 10; ++_u32local_retry)
				{
					fota_data_send_byte(EOT);
					if ((_u32result = fota_data_received((DLY_1S)<<1)) == ACK)
						break;
				}
				uUpgradeCompleted = (_u32result == ACK)? STATUS_SUCCESS : FOTA_NACK;
				break;
			}
		}

	}while (0);

	return uUpgradeCompleted;
}

/** @fn start_ESP_IMG_download
 *
 * @brief This function used to start ESP Fota
 *
 * @param N.A.
 *.
 *  @return None.(Will not Return from here.)
 */
unsigned char start_ESP_IMG_download ( void )
{
	unsigned char ucRetry = 0;
	esp_err_t err;
	esp_ota_handle_t update_handle = 0 ;
	const esp_partition_t *update_partition = NULL;
	int binary_file_length = 0;
	bool image_header_was_checked = false;
	unsigned char uFOTACompleted = STATUS_SUCCESS;
	esp_http_client_handle_t client = NULL;
	unsigned char lPartitionFound = 0;

	ESP_LOGI(FOTA_TASK_TAG, "Starting ESP OTA ...");

	do
	{
		const esp_partition_t *configured = esp_ota_get_boot_partition();
		const esp_partition_t *running = esp_ota_get_running_partition();

		//Boot partition validation
		if (configured != running) 
		{
			ESP_LOGW(FOTA_TASK_TAG, "Configured OTA boot partition at offset 0x%08x, but running from offset 0x%08x",configured->address, running->address);
			ESP_LOGW(FOTA_TASK_TAG, "(This can happen if either the OTA boot data or preferred boot image become corrupted somehow.)");
		}

		ESP_LOGI(FOTA_TASK_TAG, "Running partition type %d subtype %d (offset 0x%08x)", running->type, running->subtype, running->address);

		//@harshal : ************ Start server connection from here ************
		esp_http_client_config_t config = {
			.timeout_ms = CONFIG_OTA_RECV_TIMEOUT,
		};

		printf ("<<<<<< %s || %d >>>>>\r\n",g_esp_fota_download, strlen(g_esp_fota_download));
		config.url = (char *)&g_esp_fota_download;

#ifdef CONFIG_SKIP_COMMON_NAME_CHECK
		config.skip_cert_common_name_check = true;
#endif
		//@harshal : Http Initialize with latest configuration
		client = esp_http_client_init(&config);
		if (client == NULL) {
			ESP_LOGE(FOTA_TASK_TAG, "Failed to initialise HTTP connection");
			uFOTACompleted = FAIL;
			break;
		}

		err = esp_http_client_open(client, 0);
		if (err != ESP_OK) {
			ESP_LOGE(FOTA_TASK_TAG, "Failed to open HTTP connection: %s", esp_err_to_name(err));
			uFOTACompleted = FAIL;
			break;
		}

		esp_http_client_fetch_headers(client);

		for (ucRetry = 0 ;ucRetry < 3; ucRetry++)
		{
			update_partition = esp_ota_get_next_update_partition( update_partition );		
			if ( update_partition == NULL)
			{
				uFOTACompleted = FAIL;
				break;
			}
			ESP_LOGI(FOTA_TASK_TAG, "Writing to partition subtype %d at offset 0x%x %s",
					update_partition->subtype, update_partition->address, update_partition->label);
			if ( (strcmp((const char *)update_partition->label, (const char*)"mcu_img") == 0) || (update_partition == running ) )
			{
				ESP_LOGI(FOTA_TASK_TAG, "MCU_IMG Partition found in WIFI OTA Process");
				continue;
			}
			else
			{
				ESP_LOGI(FOTA_TASK_TAG, "ESP FOTA Partition : %s", update_partition->label);
				lPartitionFound = 1;
				break;
			}
		}

		if ( (update_partition == NULL) || ( 0 == lPartitionFound) )
		{
			uFOTACompleted = FAIL;
			break;
		}


		while (1) 
		{
			///@harshal : Read the 512 bytes from HTTp Client Handle into the "Write_Data" Buffer
			int data_read = esp_http_client_read(client, ota_write_data, BUFFSIZE);

			if (data_read < 0) 
			{
				///@harshal : Http read error
				ESP_LOGE(FOTA_TASK_TAG, "Error: SSL data read error");
				uFOTACompleted = FAIL;
				break;

			} else if (data_read > 0) {

				///@harshal : Data read from HTTP CLIENT
				///@harshal : Following If used for header application validation
				if (image_header_was_checked == false) 
				{
					esp_app_desc_t new_app_info;
					if (data_read > sizeof(esp_image_header_t) + sizeof(esp_image_segment_header_t) + sizeof(esp_app_desc_t)) {
						// check current version with downloading
						memcpy(&new_app_info, &ota_write_data[sizeof(esp_image_header_t) + sizeof(esp_image_segment_header_t)], sizeof(esp_app_desc_t));
						ESP_LOGI(FOTA_TASK_TAG, "New firmware version: %s", new_app_info.version);

						esp_app_desc_t running_app_info;
						if (esp_ota_get_partition_description(running, &running_app_info) == ESP_OK) {
							ESP_LOGI(FOTA_TASK_TAG, "Running firmware version: %s", running_app_info.version);
						}

						const esp_partition_t* last_invalid_app = esp_ota_get_last_invalid_partition();
						esp_app_desc_t invalid_app_info;
						if (esp_ota_get_partition_description(last_invalid_app, &invalid_app_info) == ESP_OK) {
							ESP_LOGI(FOTA_TASK_TAG, "Last invalid firmware version: %s", invalid_app_info.version);
						}

						// check current version with last invalid partition
						if (last_invalid_app != NULL) {
							if (memcmp(invalid_app_info.version, new_app_info.version, sizeof(new_app_info.version)) == 0) {
								ESP_LOGW(FOTA_TASK_TAG, "New version is the same as invalid version.");
								ESP_LOGW(FOTA_TASK_TAG, "Previously, there was an attempt to launch the firmware with %s version, but it failed.", invalid_app_info.version);
								ESP_LOGW(FOTA_TASK_TAG, "The firmware has been rolled back to the previous version.");
								uFOTACompleted = FAIL;
								break;
							}
						}

						//@harshal: Image version check
						if (memcmp(new_app_info.version, running_app_info.version, sizeof(new_app_info.version)) == 0) {
							ESP_LOGW(FOTA_TASK_TAG, "Current running version is the same as a new. We will not continue the update.");
							uFOTACompleted = FAIL;
							break;
						}

						image_header_was_checked = true;

						err = esp_ota_begin(update_partition, OTA_SIZE_UNKNOWN, &update_handle);
						if (err != ESP_OK) {
							ESP_LOGE(FOTA_TASK_TAG, "esp_ota_begin failed (%s)", esp_err_to_name(err));
							uFOTACompleted = FAIL;
							break;
						}
						ESP_LOGI(FOTA_TASK_TAG, "esp_ota_begin succeeded");
					} else {
						ESP_LOGE(FOTA_TASK_TAG, "received package is not fit len");
						uFOTACompleted = FAIL;
						break;
					}
				}

				err = esp_ota_write( update_handle, (const void *)ota_write_data, data_read);
				if (err != ESP_OK) {
					uFOTACompleted = FAIL;
					break;
				}
				binary_file_length += data_read;
				ESP_LOGD(FOTA_TASK_TAG, "Written image length %d\r\n", binary_file_length);

			} else if (data_read == 0) {
				if (errno == ECONNRESET || errno == ENOTCONN) {
					ESP_LOGE(FOTA_TASK_TAG, "Connection closed, errno = %d", errno);
					break;
				}
				if (esp_http_client_is_complete_data_received(client) == true) {
					ESP_LOGI(FOTA_TASK_TAG, "Connection closed");
					break;
				}
			}
		}

		if ( uFOTACompleted == STATUS_SUCCESS )
		{
			ESP_LOGI(FOTA_TASK_TAG, "Total Write binary data length: %d\r\n", binary_file_length);
			if (esp_http_client_is_complete_data_received(client) != true) {
				ESP_LOGE(FOTA_TASK_TAG, "Error in receiving complete file");
				uFOTACompleted = FAIL;
				break;
			}

			err = esp_ota_end(update_handle);
			if (err != ESP_OK) {
				if (err == ESP_ERR_OTA_VALIDATE_FAILED) {
					ESP_LOGE(FOTA_TASK_TAG, "Image validation failed, image is corrupted");
				}
				ESP_LOGE(FOTA_TASK_TAG, "esp_ota_end failed (%s)!", esp_err_to_name(err));
				uFOTACompleted = FAIL;
				break;
			}

			err = esp_ota_set_boot_partition(update_partition);
			if (err != ESP_OK) {
				ESP_LOGE(FOTA_TASK_TAG, "esp_ota_set_boot_partition failed (%s)!", esp_err_to_name(err));
				uFOTACompleted = FAIL;
				break;
			}
		} 
		else 
		{
			err = esp_ota_end(update_handle);
			if (err != ESP_OK) {
				if (err == ESP_ERR_OTA_VALIDATE_FAILED) {
					ESP_LOGE(FOTA_TASK_TAG, "Image validation failed, image is corrupted");
				}
				ESP_LOGE(FOTA_TASK_TAG, "esp_ota_end failed (%s)!", esp_err_to_name(err));
				uFOTACompleted = FAIL;
				break;
			}
		}
	}while (0);

	http_cleanup(client);
	memset(&g_esp_fota_download, '\0', sizeof(g_esp_fota_download));

	if ( FAIL != uFOTACompleted )
	{
		nvm_set_string (FOTA_PENDING_STATUS, "0");
		esp_restart();
	}

	return uFOTACompleted;	
}

/** @fn fota_MCU_Communication
 *
 * @brief This function used for MCU communication
 *
 * @param N.A.
 *.
 *  @return STATUS_SUCCESS on success else STATUS_ERROR
 */
unsigned char fota_MCU_Communication ( void )
{
	unsigned char _u8local_result = 0;

	do
	{
		//Step-1
		//Send "JUMP_BT#" to MCU
		if ( 0 == fota_data_send(FOTA_TASK_TAG, "JUMP_BT#\r\n"))
		{
			_u8local_result = STATUS_ERROR;
			break;
		}

		printf("<<<<<<<< Waiting for GOING_TO_BT# >>>>>>>\r\n");
		//Wait for "GOING_TO_BT# From MCU
		if ( STATUS_ERROR == fota_mcu_response (FOTA_RECV_GOING_TO_BT, 5000))
		{
			_u8local_result = STATUS_ERROR;
			break;
		}

		//Step-2
		printf("<<<<<<<< Waiting for MCU_BT_01_02_READY# >>>>>>>\r\n");
		//Wait for "MCU_BT_01_02_READY#"
		if ( STATUS_ERROR == fota_mcu_response (FOTA_RECV_BT_READY, 5000))
		{
			_u8local_result = STATUS_ERROR;
			break;
		}

		printf("<<<<<<<< Waiting for WAITING_FOR_FOTA# >>>>>>>\r\n");
		//Wait for "WAITING_FOR_FOTA#"
		if ( STATUS_ERROR == fota_mcu_response (FOTA_RECV_WAIT_FOR_FOTA, 5000))
		{
			_u8local_result = STATUS_ERROR;
			break;
		}

		//Dealy : 100 mSec
		vTaskDelay(100 / portTICK_PERIOD_MS);

		//Step-3
		//Send "2" to MCU
		if ( 0 == fota_data_send(FOTA_TASK_TAG, "2\r\n"))
		{
			_u8local_result = STATUS_ERROR;
			break;
		}

		//Wait for "FLASH_ERASED#
		printf("<<<<<<<< Waiting for FLASH_ERASED# >>>>>>>\r\n");
		if ( STATUS_ERROR == fota_mcu_response (FOTA_RECV_FLASH_ERASED, 5000))
		{
			_u8local_result = STATUS_ERROR;
			break;
		}

		//Send "3" to MCU
		if ( 0 == fota_data_send(FOTA_TASK_TAG, "3\r\n"))
		{
			_u8local_result = STATUS_ERROR;
			break;
		}

		//Wait for "WAITING_FOR_BIN#"
		printf("<<<<<<<< Waiting for WAITING_FOR_BIN# >>>>>>>\r\n");
		if ( STATUS_ERROR == fota_mcu_response (FOTA_RECV_WATTING_FOR_BIN, 5000))
		{
			_u8local_result = STATUS_ERROR;
			break;
		}
	}while (0);

	return _u8local_result;
}

/** @fn fota_MCU_End_comm
 *
 * @brief This function used for MCU communication
 *
 *  @return STATUS_SUCCESS on success else STATUS_ERROR
 */
unsigned char fota_MCU_End_comm ( void )
{
	unsigned char _u8local_result = 0;

	do
	{
		vTaskDelay(100 / portTICK_PERIOD_MS);
		fota_data_send_byte(0x0D);

		//Step-4
		//Wait for "BIN_UPDATED# From MCU
		printf("<<<<<<<< Waiting for BIN_UPDATED# >>>>>>>\r\n");
		if ( STATUS_ERROR == fota_mcu_response (FOTA_RECV_BIN_UPDATED, 5000))
		{
			_u8local_result = STATUS_ERROR;
			break;
		}

		//Step-5
		//Send "2" to MCU
		if ( 0 == fota_data_send(FOTA_TASK_TAG, "4\r\n"))
		{
			_u8local_result = STATUS_ERROR;
			break;
		}

		//Wait for "FLASH_ERASED#
		printf("<<<<<<<< Waiting for FLASH_ERASED# >>>>>>>\r\n");
		if ( STATUS_ERROR == fota_mcu_response (FOTA_RECV_GOING_TO_APP, 5000))
		{
			_u8local_result = STATUS_ERROR;
			break;
		}

	}while (0);

	return _u8local_result;
}


/** @fn fota_update_partition_status 
 *
 * @brief This function used to update partition status
 *
 *  @return
 */
void fota_update_partition_status (void)
{
	char u8localBuff[32] = {0};

	//Get Download partition name
	nvm_get_string ( MCU_DOWNLOAD_IMG, u8localBuff);

	if ((strcmp(gPartitionName, u8localBuff) == 0) && (strcmp(u8localBuff, MCU_BACKUP_1) == 0))
	{
		printf("Next Download Partition : %s || Backup Partition : %s\n",MCU_BACKUP_2,MCU_BACKUP_1);
		nvm_set_string (MCU_DOWNLOAD_IMG, MCU_BACKUP_2 );
		nvm_set_string (MCU_BACKUP , MCU_BACKUP_1 );

	} else if ((strcmp(gPartitionName, u8localBuff) == 0) && (strcmp(u8localBuff, MCU_BACKUP_2) == 0))
	{
		printf("Next Download Partition : %s || Backup Partition : %s\n",MCU_BACKUP_1,MCU_BACKUP_2);
		nvm_set_string (MCU_DOWNLOAD_IMG, MCU_BACKUP_1 );
		nvm_set_string (MCU_BACKUP , MCU_BACKUP_2 );

	} else if (strcmp(gPartitionName, MCU_BACKUP_1) == 0)
	{
		printf("Next Download Partition : %s || Backup Partition : %s\n",MCU_BACKUP_2,MCU_BACKUP_1);
		nvm_set_string (MCU_BACKUP , MCU_BACKUP_1 );
		nvm_set_string (MCU_DOWNLOAD_IMG, MCU_BACKUP_2 );

	} else if (strcmp(gPartitionName, MCU_BACKUP_2) == 0) {
		printf("Next Download Partition : %s || Backup Partition : %s\n",MCU_BACKUP_1,MCU_BACKUP_2);
		nvm_set_string (MCU_BACKUP , MCU_BACKUP_2 );
		nvm_set_string (MCU_DOWNLOAD_IMG, MCU_BACKUP_1 );
	}

	//Update Backup Partition Details
	//Update Img Size
	set_Backup_MCU_IMG_size( gu32ImageSize );


	memset (u8localBuff, '\0', sizeof (u8localBuff));

	//Update Major version number
	sprintf(u8localBuff, "%02d", _gst_mcu_ver.major);
	nvm_set_string (MCU_BACKUP_VER_MAJOR, u8localBuff);

	//Update Minor version number
	sprintf(u8localBuff, "%02d", _gst_mcu_ver.minor);
	nvm_set_string (MCU_BACKUP_VER_MINOR, u8localBuff);

	return;
}


/** @fn fota_update_img_details 
 *
 * @brief This function used to update image details
 *
 *  @return
 */
void fota_update_img_details (int *ImgSize, unsigned char ImgPartition)
{
	char u8localBuff[3] = {0};
	if (ImgPartition == 0)
	{
		//Provide Downloaded Image Size
		*ImgSize = get_DownLoadMCU_IMG_size();
	} else {
		//Provide Backup Image Size
		*ImgSize = get_BackupMCU_IMG_size();
		//Update Major and Minor Number

		nvm_get_string (MCU_BACKUP_VER_MAJOR, (char*)&u8localBuff);
		_gst_mcu_ver.major = atoi(u8localBuff);
		memset(u8localBuff, '\0', sizeof(u8localBuff));
		nvm_get_string (MCU_BACKUP_VER_MINOR, (char*)&u8localBuff);
		_gst_mcu_ver.minor = atoi (u8localBuff);
	}
	return;
}

/** @fn fota_service
 *
 * @brief This function used to start FOTA service
 *
 * @param N.A.
 *.
 *  @return None.(Will not Return from here.)
 */
void fota_service (void *pvParameter)
{
	EventBits_t _u32xevent_result;
	http_info _st_httpInfo_In;
	char u8localBuff[32]={0}, u8localMCUFail = 0, u8lmajor[3]={0}, u8lminor[3]={0};

	ESP_LOGI(FOTA_TASK_TAG, "**** FOTA Service Started Successfully ****");

	//Set azure service up flag and wait for all other servces
	_u32xevent_result = xEventGroupSync( g_xEventGroup,
			FOTA_SERVICE_BIT,
			SYNC_ALL_TASK,
			g_u32TaskSyncTime );

	if(SYNC_ALL_TASK != (_u32xevent_result & SYNC_ALL_TASK))
	{
		/* TODO: System reset*/
		comm_system_reboot();
	}

	//Set default azure state
	fota_event_handler ( FOTA_INIT );

	while ( 1 )
	{
		switch ( g_fota_service_stat )
		{
			case FOTA_INIT:
				//Initialize FOTA Pins
				fota_event_handler ( FOTA_WAIT );
				break;

			case FOTA_MCU_START:
				nvm_set_string (FOTA_PENDING_STATUS, "1");
				printf ("******** In FOTA_MCU_START **********\r\n");
				//Get MCU FOTA download string
				_st_httpInfo_In.device_type = DEVICE_ID_MCU;
				_st_httpInfo_In.request_type = HTTP_GET;
				_st_httpInfo_In.web_server = WEB_SERVER_FOTA;

				if ( (STATUS_SUCCESS == http_send_query_get_resp(_st_httpInfo_In)) && (strlen (g_mcu_fota_download) != 0))
				{
					printf(" HTTP send request get response success\r\n");
				} else {
					printf(" HTTP get FOTA request fail \r\n");
					fota_event_handler ( FOTA_WAIT );
					//Update Error Code
					_gu32ErrorCode = FOTA_CMD_ERROR;
					xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_FOTA_ACK );
					break;
				}

				if ( STATUS_SUCCESS == start_MCU_IMG_download() )
				{
					ESP_LOGI(FOTA_TASK_TAG, "MCU Partition write completed ! ");
					_g32mcuFotaCount = 0;
					fota_event_handler ( FOTA_WAIT );

					xEventGroupSetBits(g_xServiceStatEventGroup, COMM_MCU_FOTA_UPGRADE_START );
				} else {
					//Update Error Code
					_gu32ErrorCode = FOTA_CMD_ERROR;
					xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_FOTA_ACK );
					//If MCU Fota fail and need we received Both FOTA for upgrade
					if ( _gu8BothFOTAFlag == 1 )
					{
						fota_event_handler ( FOTA_ESP_START );
					}else{
						fota_event_handler ( FOTA_WAIT );
					}
				}
				break;

			case FOTA_MCU_UPGRADE:
				printf ("******** FOTA_MCU_UPGRADE With Retry Count [%d] **********\r\n", gFOTARetryCount);

				u8localMCUFail = 0;
				//Update Image details
				fota_update_img_details (&gu32ImageSize, gTryBackupImg);
				//Communicate with MCU
				if ( STATUS_SUCCESS == fota_MCU_Communication() )
				{
					//Read and send the data from MCU partition
					printf ("INFO : We are in FOTA Upgrade ... \r\n");
					if ( STATUS_SUCCESS == MCU_FOTA_Upgrade( gu32ImageSize ))
					{
						ESP_LOGI(FOTA_TASK_TAG, "MCU Firmware Upgrade Successfully! ");
						//Communicate with MCU
						if ( STATUS_ERROR == fota_MCU_End_comm())
						{
							//Send MCU FOAT Upgrade fail event
							ESP_LOGI(FOTA_TASK_TAG, "Fail to End Communication! \r\n");
							goto RETRY;
						} else {
							ESP_LOGI(FOTA_TASK_TAG, "End Of communication successful! \r\n");
							nvm_set_string (FOTA_PENDING_STATUS, "0");
							fota_update_partition_status();
						}
					}
					else
					{
						//Send MCU FOAT Upgrade fail event
						ESP_LOGI(FOTA_TASK_TAG, "MCU Firmware Upgrade Fail! [MCU_FOTA_Upgrade] ");
						goto RETRY;
					}
				} else {
					//MCU FOTA upgrade fail
RETRY:				ESP_LOGI(FOTA_TASK_TAG, "MCU Firmware Upgrade Fail! ");

				//Update Retry Count
				gFOTARetryCount++;
				if ( MAX_RETRY_COUNT < gFOTARetryCount )
				{
					gFOTARetryCount = 0;
					gTryBackupImg = 0;

					nvm_get_string ( MCU_DOWNLOAD_IMG, u8localBuff);
					if (strlen(u8localBuff) > 0)
					{
						//Update Download Partition to NULL
						nvm_erase_string ( MCU_DOWNLOAD_IMG, NULL); //Update New Partition
					} else {
						//Update Download Partition to NULL
						nvm_erase_string ( MCU_BACKUP, NULL);
						//Erase Backup Partition Details
						nvm_erase_string ( MCU_BACKUP_SIZE, NULL);
						nvm_erase_string ( MCU_BACKUP_VER_MAJOR, NULL);
						nvm_erase_string ( MCU_BACKUP_VER_MINOR, NULL);
						u8localMCUFail = 1;
					}

					memset (gPartitionName, '\0', sizeof(gPartitionName));

					//Check Backup partition
					nvm_get_string ( MCU_BACKUP, gPartitionName); //Update New Partition

					if (strlen(gPartitionName) > 0)
					{
						gTryBackupImg = 1;
						vTaskDelay(10000 / portTICK_PERIOD_MS);
						fota_event_handler ( FOTA_MCU_UPGRADE );
						break;
					} else {
						u8localMCUFail = 1;
					}

				} else {
					vTaskDelay(10000 / portTICK_PERIOD_MS);
					fota_event_handler ( FOTA_MCU_UPGRADE );
					break;
				}
				}

				if (u8localMCUFail)
				{
					//Update Error Code
					_gu32ErrorCode = FOTA_CMD_ERROR;
					xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_FOTA_ACK );

				} else {
					//Update MCU version
					sprintf(u8lmajor,"%02d",_gst_mcu_ver.major);
					nvm_set_string (MCU_VER_MAJOR, u8lmajor);

					sprintf(u8lminor,"%02d",_gst_mcu_ver.minor);
					nvm_set_string (MCU_VER_MINOR, u8lminor);

					gFOTARetryCount = 0;
					gTryBackupImg = 0;

				}
				//Send MCU_FOTA_COMPLETED event
				xEventGroupSetBits(g_xServiceStatEventGroup, COMM_MCU_FOTA_COMPLETED);

				//If MCU Fota fail and need we received Both FOTA for upgrade
				if ( _gu8BothFOTAFlag == 1 )
				{
					fota_event_handler ( FOTA_ESP_START );
				} else {
					fota_event_handler ( FOTA_WAIT );
				}

				break;

			case FOTA_ESP_START:
				printf ("******** In FOTA_ESP_START **********\r\n");
				nvm_set_string (FOTA_PENDING_STATUS, "1");

				//Send ESP FOTA Started event
				xEventGroupSetBits(g_xServiceStatEventGroup, COMM_ESP_FOTA_STARTED );

				_st_httpInfo_In.device_type = DEVICE_ID_ESP;
				_st_httpInfo_In.request_type = HTTP_GET;
				_st_httpInfo_In.web_server = WEB_SERVER_FOTA;


				if ( (STATUS_SUCCESS == http_send_query_get_resp(_st_httpInfo_In)) && (strlen (g_esp_fota_download) != 0))
				{
					printf(" HTTP send request get response success\r\n");
				} else {
					printf(" HTTP get FOTA request fail \r\n");
					fota_event_handler ( FOTA_WAIT );
					//Update Error Code
					_gu32ErrorCode = FOTA_CMD_ERROR;
					xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_FOTA_ACK );
					break;
				}

				if ( STATUS_SUCCESS == start_ESP_IMG_download())
				{
					//Send Event ESP FOTA Completed
				}else{
					//Send Event ESP FOTA Fail
					//Update Error Code
					_gu32ErrorCode = FOTA_CMD_ERROR;
					xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_FOTA_ACK );
				}

				_gu8BothFOTAFlag = 0;

				fota_event_handler ( FOTA_WAIT );
				break;

			case FOTA_START_BOTH:
				ESP_LOGI(FOTA_TASK_TAG, " <<<< BOTH Firmware For update received >>>>\r\n");
				_gu8BothFOTAFlag = 1;
				fota_event_handler ( FOTA_MCU_START );
				break;

			case FOTA_ESP_COMPLETED:
				// Send ESP FOTA Completed
				break;

			case FOTA_WAIT:
			default:
				vTaskDelay(1000 / portTICK_PERIOD_MS);
				break;
		}
	}
}
