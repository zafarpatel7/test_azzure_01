#include "serial_comm.h"
#include "common.h"
#include "flash.h"
#include "string.h"

/**** Define ****************/
/****** All globle variabl ***********/
static const int RX_BUF_SIZE = 512;
static const char *SComm_TASK_TAG = "_SComm_";
int _gu32TxCommand = 0;
int _gu32RxCommand = 0;
time_t gCurrentTimeForMCU = 0;

/********** All extern variable *******/
extern char g_cloud_data[512];
extern unsigned char g_send_data_to_cloud;
extern char gDataForController[512];
extern bool gSendDataToController;

//This function used to change the TX state
void SC_TX_Stat_change ( int _u32TxStat )
{
	_gu32TxCommand = _u32TxStat;
}

/** @fn sendData
 *
 * @brief This function used to send data on UART through TX Thread
 *
 * @param logName : Used for log taging
 * @param data  : Data which we need to send
 *.
 *  @return Number of bytes transmitted on UART
 */
int sendData(const char* logName, const char* data)
{
	const int len = strlen(data);
	const int txBytes = uart_write_bytes(UART_NUM_1, data, len);
	ESP_LOGI(logName, "Wrote %d bytes", txBytes);
	return txBytes;
}

//This function used to update the Tx event
unsigned char SC_TX_update_tx_event ( int _u32event_In)
{
	if ( _u32event_In == TX_RESUME_HOLD_STATE )
	{
		_gu32TxCommand = _u32event_In;
	}
	else if ( _gu32TxCommand == TX_HOLD_STATE )
	{
		return STATUS_ERROR;
	}
	else
	{
		_gu32TxCommand = _u32event_In;
	}

	return STATUS_SUCCESS;
}

//This function used to update the Rx event
unsigned char SC_RX_update_rx_event ( int _u32event_In)
{
	if ( _u32event_In == RX_RESUME_HOLD_STATE )
	{
		_gu32RxCommand = _u32event_In;
	}
	else if ( _gu32RxCommand == RX_HOLD_STATE )
	{
		return STATUS_ERROR;
	}
	else
	{
		_gu32RxCommand = _u32event_In;
	}

	return STATUS_SUCCESS;
}

/** @fn tx_task
 *
 * @brief This function used to trasnmit the data over UART to the MCU
 *
 * @param N.A.
 *.
 *  @return None.(Will not Return from here.)
 */
void tx_task ( void *param )
{
	char u8localBuff[16] = {0};
	//NOTE : This is temparery thread we have to create thread only from serial communication
	esp_log_level_set(SComm_TASK_TAG, ESP_LOG_INFO);

	_gu32TxCommand = TX_WAIT;

	while (1)
	{

		switch ( _gu32TxCommand )
		{
			case TX_SEND_DATA_TO_MCU:
				sendData(SComm_TASK_TAG, (const char*)gDataForController);
				gSendDataToController = false;
				SC_TX_update_tx_event ( TX_WAIT );
				break;

			case TX_SEND_WIFI_CONFIG_ACK:
				sendData(SComm_TASK_TAG, "WIFI_SETUP_DONE\r\n");
				SC_TX_update_tx_event ( TX_WAIT );
				break;

			case TX_SEND_ESP_RST_TO_MCU:
				sendData(SComm_TASK_TAG, "MCU_RST#\r\n");
				SC_TX_update_tx_event ( TX_WAIT );
				break;

			case TX_HOLD_STATE:
				//NOTE : If device is in MCU FOTA upgrade process then Pause the transmission thread
				vTaskDelay(500 / portTICK_PERIOD_MS);
				break;

			case TX_RESUME_HOLD_STATE:
				SC_TX_update_tx_event ( TX_WAIT );
				break;

			case TX_SEND_CURRENT_TIME:
				sprintf (u8localBuff, "%lu\r\n", gCurrentTimeForMCU);
				printf("<<<<<<<<<<<< Current time :: %s\n", u8localBuff);
				sendData(SComm_TASK_TAG, u8localBuff);
				SC_TX_update_tx_event ( TX_WAIT );
				break;

			case TX_WAIT:
			default:
				vTaskDelay(500 / portTICK_PERIOD_MS);
				break;
		}
	}
}

//Description : This function used to get the serial number from MCU command
unsigned char SC_Get_Board_serial_Number(unsigned char *_u8rx_data_In, char *SerialNum)
{
	unsigned char _u8local_result = STATUS_ERROR, _u8localSize = 0;
	char *plocalStartPtr = NULL, *plocalEndPtr = NULL;

	do
	{
		if ( _u8rx_data_In == NULL)
		{
			break;
		}

		plocalStartPtr = (char*)_u8rx_data_In;

		plocalEndPtr = strstr((char*)plocalStartPtr, "_");
		if (plocalEndPtr != NULL)
		{
			_u8localSize = plocalEndPtr - plocalStartPtr;

			strncpy( (char*)SerialNum, plocalStartPtr, _u8localSize);

			_u8local_result = STATUS_SUCCESS;
		}
	}while (0);

	return _u8local_result;
}

unsigned char SC_Get_MCU_version(unsigned char *_u8rx_data_In, char *_u8major_In, char *_u8minor_In)
{
	unsigned char _u8local_result = STATUS_ERROR;
	char *plocalStartPtr = NULL, *plocalPtr = NULL;

	do
	{
		if ( _u8rx_data_In == NULL || _u8major_In == NULL || _u8minor_In == NULL )
		{
			break;
		}

		plocalPtr = (char*)_u8rx_data_In;

		plocalStartPtr = strstr(plocalPtr, "_AP_");
		if (plocalStartPtr != NULL)
		{
			plocalStartPtr = plocalStartPtr + 4;

			strncpy (_u8major_In, plocalStartPtr, 2);
			plocalStartPtr = plocalStartPtr + 3;
			strncpy (_u8minor_In, plocalStartPtr, 2);

			_u8local_result = STATUS_SUCCESS;
		}
	}while (0);

	return _u8local_result;
}

/** @fn serial_comm_service
 *
 * @brief This function used to start the serial communication service
 *
 * @param N.A.
 *.
 *  @return None.(Will not Return from here.)
 */
void serial_comm_service(void *param)
{
	char *pResult = NULL;
	uint32_t len = 0;
	EventBits_t _u32xevent_result;
	char _u8SerialNum[16] = {0}, _u8major[3] = {0}, _u8minor[3] = {0};
	char _u8localSrNo[16] = {};

	esp_log_level_set(SComm_TASK_TAG, ESP_LOG_INFO);

	uint8_t* _u8rx_data = (uint8_t*) malloc(RX_BUF_SIZE+1);

	if( NULL == _u8rx_data)
	{
		ESP_LOGI(SComm_TASK_TAG, " FAIL to allocate memmory for Rx Buffer");
	}

	ESP_LOGI(SComm_TASK_TAG, "**** Serial Communication Service (RX) Started Successfully ****");

	//Set azure service up flag and wait for all other servces
	_u32xevent_result = xEventGroupSync( g_xEventGroup,
			SERIAL_COMM_SERVICE_BIT,
			SYNC_ALL_TASK,
			g_u32TaskSyncTime );

	if(SYNC_ALL_TASK != (_u32xevent_result & SYNC_ALL_TASK))
	{
		/* TODO: System reset*/
		//main_system_reboot();
	}

	SC_RX_update_rx_event (RX_GET_COMMAND);

	while (1)
	{
		switch ( _gu32RxCommand )
		{
			case RX_HOLD_STATE:
				vTaskDelay(500 / portTICK_PERIOD_MS);
				break;

			case RX_RESUME_HOLD_STATE:
				SC_RX_update_rx_event (RX_GET_COMMAND);
				break;

			case RX_GET_COMMAND:
			default:
				{
					const int rxBytes = uart_read_bytes(UART_NUM_1, _u8rx_data, RX_BUF_SIZE, 1000 / portTICK_RATE_MS);
					if (rxBytes > 0)
					{
						_u8rx_data[rxBytes] = 0;

						ESP_LOGI(SComm_TASK_TAG, "Read %d bytes: '%s'", rxBytes, _u8rx_data);

						pResult = strstr((const char*)_u8rx_data, (const char*)"WAITING_FOR_BIN#");
						if(pResult != NULL)
						{
							printf ("@@@@@@@  SEND FOTA REQUEST TO THE SERVER @@@@@@\r\n");
							xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_FOTA_REQUEST );

						} else {
							pResult = strstr((const char*)_u8rx_data, (const char*)"WIFI_CONFIG");
							if(pResult != NULL)
							{
								printf ("@@@@@@@  GOING TO START WIFI CONFIG @@@@@@\r\n");
								xEventGroupSetBits(g_xServiceStatEventGroup, COMM_SMARTCONFIG_START);

							} else {
								pResult = strstr((const char *)_u8rx_data,(const char *)"SEND#");
								if(pResult != NULL)
								{
									//TODO : Transmit this data to Azure
									if(g_send_data_to_cloud == 0)
									{
										len = (pResult - (char *)_u8rx_data);
										memset(g_cloud_data, '\0', sizeof(g_cloud_data));

										//Copy Data into global buffer
										strncpy((char *)g_cloud_data, (const char*)_u8rx_data, len);

										//Update for send data
										g_send_data_to_cloud = 1;

										xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_SEND_COMMAND );

									} else {
										memset(_u8rx_data, '\0', (RX_BUF_SIZE+1));
									}
								}
								else
								{
									//CONFIG#
									pResult = strstr((const char *)_u8rx_data,(const char *)"ESP_RST#");
									if(pResult != NULL)
									{
										//TODO : Have to decide what to do
										memset(_u8rx_data, '\0', (RX_BUF_SIZE+1));
										comm_system_reboot();
									}
									else
									{
										pResult = strstr((const char *)_u8rx_data,(const char *)"_MCU_AP_");
										if(pResult != NULL)
										{
											//Get Serial Number
											if ( STATUS_SUCCESS == SC_Get_Board_serial_Number(_u8rx_data, (char *)&_u8SerialNum) )
											{
												//Get Serial Number from Flash
												nvm_get_string (DEVICE_SERIAL_NUM, _u8localSrNo);

												//Remain To handle
												if (strlen(_u8localSrNo))
												{
													if (strcmp(_u8localSrNo,(char*)_u8SerialNum) != 0)
													{
														//NOTE : If change of serial number found then erase previous
														//		connection string and serial no and reboot the system
														//Clear serial number from flash
														nvm_erase_string (DEVICE_SERIAL_NUM, "Erase");
														//Clear connection string from flash
														nvm_erase_string (AZURE_CONNECTION_STR, "Erase");
														//													comm_system_reboot();
														xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_CHANGE_CSTR_REQ );

													}
												}

												//Set serial number
												comm_set_serial_number(_u8SerialNum);

												//Get MCU version
												memset(_u8major, '\0', sizeof(_u8major));
												memset(_u8minor, '\0', sizeof(_u8minor));
												SC_Get_MCU_version(_u8rx_data, (char*)&_u8major, (char*)&_u8minor);

												//Update version number
												if (strlen((char*)_u8major) == 2)
													nvm_set_string (MCU_VER_MAJOR,(char*) _u8major);
												else
													nvm_set_string (MCU_VER_MAJOR, "FF"); //Invalid firmware version received

												if (strlen((char*)_u8minor) == 2)
													nvm_set_string (MCU_VER_MINOR, (char*)_u8minor);
												else
													nvm_set_string (MCU_VER_MAJOR, "FF"); //Invalid firmware version received

												memset(_u8rx_data, '\0', (RX_BUF_SIZE+1));
												g_MCU_powerOn = 1; //Set MCU is power on

											}
											else
											{
												//Maintain wrong MCU version received
												ESP_LOGI(SComm_TASK_TAG, " Wrong Power On Packet Received \r\n");
											}
										}
										else
										{
											pResult = strstr((const char*)_u8rx_data, (const char*)"GET_TIME#");
											if(pResult != NULL)
											{
												printf ("@@@@@@@  SEND CURRENT TIME TO MCU @@@@@@\r\n");
												xEventGroupSetBits(g_xServiceStatEventGroup, COMM_SEND_TIME_TO_MCU );

											} else {
												//Maintain wrong MCU version received
												ESP_LOGI(SComm_TASK_TAG, " Wrong Power On Packet Received \r\n");
											}
										}
									}
								}
							}
						}
					}
				}
				break;
		}
	}

	free(_u8rx_data);
}
