/**
 * @file main.c
 * @author Harshal
 * @date 6 Feb 2020
 * @brief This is main file of the project
 *
 * This file consist of main businees logic and start of the application
 */

/*------ System header include files ------*/
#include <stdio.h>

/*------ Local header include files ------*/
#include "cJSON.h"
#include "common.h"
#include "flash.h"
#include "azure_comm.h"
#include "wifi_control.h"
#include "serial_comm.h"
#include "led_control.h"
#include "data_indication.h"
#include "fota_service.h"
#include "http_services.h"
#include "json.h"

/**
 * @brief MCU TX and RX pins 
 */
#define MCU_TXD_PIN (GPIO_NUM_16)
#define MCU_RXD_PIN (GPIO_NUM_17)

/*------ Declare global variables here ------*/
char smartconfigFlag = 0;
bool gSendAckForWifiSetting = false;

extern char g_ssid[32];
extern char g_pass[32];
extern char g_reconnect[2];
extern time_t gCurrentTimeForMCU;

static const int RX_BUF_SIZE = 1024;

unsigned char g_send_data_to_cloud = 0;
char g_cloud_data[512];

/** 
 *
 * @brief This function used to configure the GPIO pins
 *
 * @return NA 
 */
void main_gpio_conf( void )
{
	gpio_pad_select_gpio(BLINK_GPIO);
	/* Set the GPIO as a push/pull output */
	gpio_set_direction(BLINK_GPIO, GPIO_MODE_OUTPUT);
}

/** 
 *
 * @brief This function used to initialize uart
 *
 * @return NA 
 */
void main_uart_init( void )
{
	const uart_config_t uart_config = {
		.baud_rate = 115200,
		.data_bits = UART_DATA_8_BITS,
		.parity = UART_PARITY_DISABLE,
		.stop_bits = UART_STOP_BITS_1,
		.flow_ctrl = UART_HW_FLOWCTRL_DISABLE
	};
	uart_param_config(UART_NUM_1, &uart_config);
	uart_set_pin(UART_NUM_1, MCU_TXD_PIN, MCU_RXD_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
	// We won't use a buffer for sending data.
	uart_driver_install(UART_NUM_1, RX_BUF_SIZE * 2, 0, 0, NULL, 0);
}

/*------ Functions Definitions ------*/
/** 
 *
 * @brief This function used to initialze all system call
 *
 * @return NA 
 */
void main_system_init ( void )
{
	// Initialize NVS	
	nvs_config();

	//Configuration of GPIO
	main_gpio_conf();

	//UART Initialization
	main_uart_init();
}

/** 
 *
 * @brief This function used to process the events
 *
 * @return NA 
 */
void main_process_event ( void )
{
	EventBits_t uxBits;
	/* wifi service queue message */
	msg_info _st_wifi_stat_msg;
	int Status = 0;

	uxBits = xEventGroupGetBits(g_xServiceStatEventGroup);

	//Read WIFI Connected event
	if ( uxBits & COMM_WIFI_CONNECTED )
	{
		printf ("EVENT : WIFI CONNECTED .....\r\n");
		//Get Azure connection stat
		if( AZURE_CONNECT != azure_get_state())
		{
			printf ("EVENT : Going into azure connection string stat ...\r\n");
			//Change Azure Stat
			//AZURE_CHECK_CONNECTION_STRING
			azure_set_state(AZURE_CHECK_CONNECTION_STRING);
			//Change LED Stat
			led_stat_change (LED_FAIL_TO_CONNECTING_TO_AZURE);

		} else {

			printf ("EVENT : Azure connected succefully ... \r\n");
			azure_set_state(AZURE_CONNECT);
			//Change LED Stat
			led_stat_change (LED_WIFI_N_AZURE_CON_SUCCESSFULLY);
		}

		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_WIFI_CONNECTED);
	}

	//Read WIFI Disconnected event
	if ( uxBits & COMM_WIFI_DISCONNECT )
	{
		//Change LED stat
		printf ("***** Disconneted Event Recived ************\r\n");
		//Change Azure Stat
		//Azure would be in pause / disconnect stat
		if( AZURE_CONNECT == azure_get_state())
		{
			azure_set_state(AZURE_DEINIT);
		}
		//azure_set_state(AZURE_DEINIT);
		led_stat_change (LED_WIFI_DISCONNECTED);
		//Change FOTA Stat
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_WIFI_DISCONNECT);
	}

	//Read Azure Connected event
	if ( uxBits & COMM_AZURE_CONNECTED )
	{
		//Change LED stat
		led_stat_change (LED_WIFI_N_AZURE_CON_SUCCESSFULLY);
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_AZURE_CONNECTED);		
	}

	//Read Azure disconnected event
	if ( uxBits & COMM_AZURE_DISCONNECTED )
	{
		//Change LED Stat
		led_stat_change (LED_FAIL_TO_CONNECTING_TO_AZURE);
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_AZURE_DISCONNECTED);	
	}	

	//Read MCU FOTA Completed Event
	if ( uxBits & COMM_MCU_FOTA_COMPLETED )
	{
		//Start Communication with MCU application
		SC_TX_update_tx_event (TX_RESUME_HOLD_STATE);
		//Stop Rx communication between ESP and MCU application
		SC_RX_update_rx_event (RX_RESUME_HOLD_STATE);
		//Send Power On Packet to Azure
		azure_send_command(AZURE_POWERON_PACKET);
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_MCU_FOTA_COMPLETED);		
	}	

	//Read ESP FOTA Started Event
	if ( uxBits & COMM_ESP_FOTA_STARTED )
	{
		printf ("********** ESP FOAT STARTED **********\r\n");
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_ESP_FOTA_STARTED);		
	}

	//Read ESP FOTA Completed Event
	if ( uxBits & COMM_ESP_FOTA_COMPLETED )
	{
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_ESP_FOTA_COMPLETED);		
	}

	//Read COMM_SMARTCONFIG_IN_PROGRESS Event
	if ( uxBits & COMM_SMARTCONFIG_IN_PROGRESS )
	{
		led_stat_change (LED_WIFI_SMART_CONFIG);
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_SMARTCONFIG_IN_PROGRESS);		
	}	

	//Read COMM_SMARTCONFIG_START Event
	if ( uxBits & COMM_SMARTCONFIG_START )
	{
		printf ("@@@@@@@  IN START WIFI CONFIG EVENT @@@@@@\r\n");
		_st_wifi_stat_msg.service_id = WIFI_SERVICE_REQID;
		_st_wifi_stat_msg.cmd = WIFI_GET_USER_SSID_PASS;
		//Send stat change message to the Wifi control
		xQueueSend(g_wifi_control_req_queue, &_st_wifi_stat_msg, WIFI_SERVICE_TXQ_TIMEOUT);
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_SMARTCONFIG_START);		
	}

	//Read Start MCU FOTA Event
	if ( uxBits & COMM_START_MCU_FOTA )
	{
		printf ("<<<<<<<<< IN COMM_START_MCU_FOTA >>>>>>>>>\r\n");
		//Start MCU FOTA
		if( fota_update_fota_event (FOTA_MCU_START) == FAIL)
		{
			printf ("INFO : MCU / ESP fota is in progress ....");
		}
		//Clear COMM_START_MCU_FOTA Event
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_START_MCU_FOTA );
	}

	//Read Start ESP FOTA Event
	if ( uxBits & COMM_START_ESP_FOTA )
	{
		printf ("<<<<<<<<< IN COMM_START_ESP_FOTA >>>>>>>>>\r\n");
		//Start ESP FOTA
		if( fota_update_fota_event (FOTA_ESP_START) == FAIL)
		{
			printf ("INFO : MCU / ESP fota is in progress ....");
		}
		//Clear COMM_START_ESP_FOTA Event
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_START_ESP_FOTA );
	}

	//Read COMM_AZURE_SEND_COMMAND
	if ( uxBits & COMM_AZURE_SEND_COMMAND )
	{
		printf ("<<<<<<<<< IN COMM_AZURE_SEND_COMMAND >>>>>>>>>\r\n");
		
		Status = azure_get_connection_status();
		//Get Azure Connection state
		if (COMM_AZURE_CONNECTED != Status)
		{
			//Update for send data
			g_send_data_to_cloud = 0;
			
		} else if (COMM_AZURE_CONNECTED == Status){
			
			//Send Packet on Azure
			azure_send_command(AZURE_DATA_PACKET);
		}

		//Clear COMM_AZURE_SEND_COMMAND Event
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_AZURE_SEND_COMMAND );
	}

	//Read COMM_SEND_DATA_TO_MCU
	if ( uxBits & COMM_SEND_DATA_TO_MCU )
	{
		//Inform to Tx service to send the data
		SC_TX_update_tx_event (TX_SEND_DATA_TO_MCU);
		//Clear COMM_SEND_DATA_TO_MCU Event
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_SEND_DATA_TO_MCU );
	}

	//Read COMM_SMARTCONFIG_DONE
	if ( uxBits & COMM_SMARTCONFIG_DONE )
	{
		//Inform to Tx service to send the data
		SC_TX_update_tx_event (TX_SEND_WIFI_CONFIG_ACK);

		//Clear COMM_SMARTCONFIG_DONE Event
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_SMARTCONFIG_DONE );
	}

	//Read COMM_MCU_FOTA_UPGRADE_START
	if ( uxBits & COMM_MCU_FOTA_UPGRADE_START )
	{
		//Stop Tx communication between ESP and MCU application
		SC_TX_update_tx_event (TX_HOLD_STATE);

		//Stop Rx communication between ESP and MCU application
		SC_RX_update_rx_event (RX_HOLD_STATE);

		//Start MCU_FOTA_UPGRADE
		fota_update_fota_event( FOTA_MCU_UPGRADE );

		//Clear COMM_SMARTCONFIG_DONE Event
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_MCU_FOTA_UPGRADE_START );
	}

	//Read COMM_START_BOTH_FOTA
	if ( uxBits & COMM_START_BOTH_FOTA )
	{
		printf ("INFO :::: COMM_START_BOTH_FOTA ..... \r\n");
		//Send FOTA For both firmware FOTA_START_BOTH
		fota_update_fota_event( FOTA_START_BOTH );

		//Clear COMM_SMARTCONFIG_DONE Event
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_START_BOTH_FOTA );
	}

	//Read COMM_AZURE_CHANGE_CSTR_REQ
	if ( uxBits & COMM_AZURE_CHANGE_CSTR_REQ )
	{
		printf ("INFO :::: COMM_AZURE_CHANGE_CSTR_REQ ..... \r\n");
		//Restart Azure
		azure_set_state(AZURE_DEINIT);

		//Clear COMM_AZURE_CHANGE_CSTR_REQ Event
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_AZURE_CHANGE_CSTR_REQ );

		//We have to reconnect the azure with new connection string using WIFI_CONNETED event
		xEventGroupSetBits(g_xServiceStatEventGroup, COMM_WIFI_CONNECTED);
	}


	//Read COMM_AZURE_FOTA_REQUEST
	if ( uxBits & COMM_AZURE_FOTA_REQUEST )
	{
		printf ("<<<<<<<<< IN COMM_AZURE_FOTA_REQUEST >>>>>>>>>\r\n");

		//Get Azure Connection state
		if (COMM_AZURE_CONNECTED != azure_get_connection_status())
			//Update for send data
			g_send_data_to_cloud = 0;

		//Start ESP FOTA
		azure_send_command(AZURE_FOTA_REQUEST);

		//Clear COMM_AZURE_FOTA_REQUEST Event
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_AZURE_FOTA_REQUEST );
	}

	//Read COMM_AZURE_FOTA_ACK
	if ( uxBits & COMM_AZURE_FOTA_ACK )
	{
		printf ("<<<<<<<<< IN COMM_AZURE_FOTA_ACK >>>>>>>>>\r\n");

		//Get Azure Connection state
		if (COMM_AZURE_CONNECTED != azure_get_connection_status())
			//Update for send data
			g_send_data_to_cloud = 0;

		//Send ACK Command
		azure_send_command(AZURE_FOTA_ACK);

		//Clear COMM_AZURE_FOTA_REQUEST Event
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_AZURE_FOTA_ACK );
	}

	//Read COMM_SEND_TIME_TO_MCU
	if ( uxBits & COMM_SEND_TIME_TO_MCU )
	{
		//Get Azure status
		if (COMM_AZURE_CONNECTED == azure_get_connection_status())
		{
			//Get Time
			time(&gCurrentTimeForMCU);
		} else {
			gCurrentTimeForMCU = 0;
		}

		//Inform to Tx service to send the data
		SC_TX_update_tx_event (TX_SEND_CURRENT_TIME);

		//Clear COMM_SEND_TIME_TO_MCU Event
		xEventGroupClearBits(g_xServiceStatEventGroup, COMM_SEND_TIME_TO_MCU );
	}

	return;
}


/** 
 *
 * @brief This function used to create all thread
 *
 * @return NA 
 */
void main_create_all_services ( void )
{
	printf ("****** Start all thread **********\r\n");
#ifdef ENABLE_SERVICE_SERIAL_COMM
	//Create thread for Serial Receive
	if( xTaskCreate(serial_comm_service, "uart_rx_task", 1024*2, NULL, configMAX_PRIORITIES, NULL) != pdPASS)
	{
		printf("create uart RX task failed\r\n");
		comm_system_reboot();
	}

	//Create TX Task
	if( xTaskCreate(tx_task, "uart_tx_task", 1024*2, NULL, configMAX_PRIORITIES, NULL) != pdPASS)
	{
		printf("create uart TX task failed\r\n");
		comm_system_reboot();
	}
#endif

#ifdef ENABLE_SERVICE_WIFI
	//Create wifi communication threads
	if( xTaskCreate(wifi_control_service, "wifi_task", 1024*10, NULL, configMAX_PRIORITIES, NULL) != pdPASS)
	{
		printf("[ERROR] : Fail to create wifi task\r\n");
		comm_system_reboot();
	}
#endif 
#ifdef ENABLE_SERVICE_AZURE	
	//Create Azure communication thread
	if ( xTaskCreate(&azure_service, "azure_task", 1024 * 5, NULL, configMAX_PRIORITIES, NULL) != pdPASS ) 
	{
		printf("[ERROR] : Fail to create azure task\r\n");
		comm_system_reboot();
	}
#endif
#ifdef ENABLE_SERVICE_LED	
	//Create LED Control thread
	if( xTaskCreate(led_control_service, "LED_task", 1024*3, NULL, configMAX_PRIORITIES, NULL) != pdPASS)
	{
		printf("[ERROR] : Fail to create LED task\r\n");
		comm_system_reboot();
	}
#endif
#ifdef ENABLE_SERVICE_DI
	//Create LED Control thread
	if( xTaskCreate(data_indication_service, "DI_task", 1024*3, NULL, configMAX_PRIORITIES, NULL) != pdPASS)
	{
		printf("[ERROR] : Fail to create DI task\r\n");
		comm_system_reboot();
	}
#endif
#ifdef ENABLE_SERVICE_FOTA
	//Create FOTA communication theard
	if( xTaskCreate(fota_service, "FOTA_task", 1024*6, NULL, configMAX_PRIORITIES, NULL) != pdPASS)
	{
		printf("[ERROR]  : Fail to create FOTA task\r\n");
		comm_system_reboot();
	}	
#endif

	printf ("****** End all thread **********\r\n");

	return;
}

/** 
 *
 * @brief This function used to process the events
 *
 * @return NA 
 */
void main_update_event_bit ( void )
{
	printf("***** In update Event *****\r\n");
	//Update the event bit as per the use of thread
#ifndef ENABLE_SERVICE_AZURE
	xEventGroupSetBits(g_xEventGroup, AZURE_SERVICE_BIT);
#endif
#ifndef ENABLE_SERVICE_WIFI
	xEventGroupSetBits(g_xEventGroup, WIFI_SERVICE_BIT);
#endif
#ifndef ENABLE_SERVICE_FOTA
	xEventGroupSetBits(g_xEventGroup, FOTA_SERVICE_BIT);
#endif
#ifndef ENABLE_SERVICE_LED
	xEventGroupSetBits(g_xEventGroup, LED_CONTROL_SERVICE_BIT);
#endif
#ifndef ENABLE_SERVICE_SERIAL_COMM
	xEventGroupSetBits(g_xEventGroup, SERIAL_COMM_SERVICE_BIT);
#endif
#ifndef ENABLE_SERVICE_HTTP
	xEventGroupSetBits(g_xEventGroup, HTTP_SERVER_BIT);
#endif
#ifndef ENABLE_SERVICE_DIAGNOSTIC
	xEventGroupSetBits(g_xEventGroup, DIAGNOSTIC_SERVICE_BIT);
#endif
#ifndef ENABLE_SERVICE_DI
	xEventGroupSetBits(g_xEventGroup, DATA_INDICATION_SERVICE_BIT);
#endif
	printf("***** End update Event *****\r\n");

	return;
} 

/** 
 *
 * @brief Detail This function used to create message queue for communication between therads
 *
 * @return NA
 */
unsigned char main_create_message_queue ( void )
{
	unsigned char _u8status = STATUS_SUCCESS;

#ifdef	ENABLE_SERVICE_WIFI
	/* Create the queue for "Wifi Control service" to received the request from event process */
	g_wifi_control_req_queue = xQueueCreate( QUEUE_LENGTH, sizeof( msg_info ) );
	if( NULL == g_wifi_control_req_queue )
	{
		_u8status = STATUS_ERROR;
	}
#endif

	return _u8status;
}


/**
 *
 * @brief Detail This is start function of application
 *
 * @return NA 
 */
 void app_main( void )
{
	EventBits_t _u32xevent_result;

	//System Initialize
	main_system_init();

	printf("************* Start azure_main : app_main() function ***************\r\n");

	//Create a event group for thread syncronization
	g_xEventGroup = xEventGroupCreate();

	if ( NULL == g_xEventGroup )
	{
		printf("[ERROR] : Fail to create event group\r\n");
		//system restart
		comm_system_reboot();
	}

	//Create a event for all thread status
	g_xServiceStatEventGroup = xEventGroupCreate();

	if ( NULL == g_xServiceStatEventGroup )
	{
		printf("[ERROR] : Fail to create event group\r\n");
		//system restart
		comm_system_reboot();
	}

	//Create Smart Config Event here
	g_xSmartConfigEventGroup = xEventGroupCreate();

	if ( NULL == g_xSmartConfigEventGroup )
	{
		printf("[ERROR] : Fail to create smart config event group\r\n");
		//system restart
		//comm_system_reboot();
		vTaskDelete(NULL);
	}

	//Create Message Queue
	main_create_message_queue ();

	//Create all services
	main_create_all_services();

	//Update dummy thread status bit as per the requirement
	main_update_event_bit();

	//Wait for all threads
	_u32xevent_result = xEventGroupSync( g_xEventGroup,
			SYNC_ALL_TASK_BIT,
			SYNC_ALL_TASK,
			g_u32TaskSyncTime );

	if(SYNC_ALL_TASK != (_u32xevent_result & SYNC_ALL_TASK))
	{
		//System reboot
		comm_system_reboot();
	}

	//Start Event handling
	while ( 1 )
	{
		main_process_event();
		vTaskDelay(100 / portTICK_PERIOD_MS);
	}
}

//Tested
void TestCaseForLEDThread ( void )
{
	unsigned char TestCount = 0;
	
	do
	{
		TestCount++;
		if(TestCount == 5)
		{
			//LED_WIFI_SMART_CONFIG
			xEventGroupSetBits(g_xServiceStatEventGroup, COMM_SMARTCONFIG_IN_PROGRESS);
		}
		if(TestCount == 10)
		{
			//Wifi disconnect LED_WIFI_DISCONNECTED
			xEventGroupSetBits(g_xServiceStatEventGroup, COMM_WIFI_DISCONNECT);
		}
		if(TestCount == 15)
		{
			//LED_INTERNET_NOT_AVAILABLE || LED_FAIL_TO_CONNECTING_TO_AZURE
			xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_DISCONNECTED);
		}
		if(TestCount == 25)
		{
			//LED_WIFI_N_AZURE_CON_SUCCESSFULLY
			xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_CONNECTED);
		}
		vTaskDelay(5000 / portTICK_PERIOD_MS);
	}while ( TestCount != 30);
}
