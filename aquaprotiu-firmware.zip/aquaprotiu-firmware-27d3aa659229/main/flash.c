#include "flash.h"
#include "common.h"

// NVS handler
nvs_handle g_nvmHandle;

/** @fn nvs_config
 *
 * @brief This function used to configure NVM Memory
 *
 * @param void
 *.
 *  @return NA
 */
void nvs_config ( void )
{
	// initialize NVS flash
	esp_err_t _l_result = nvs_flash_init();

	// if it is invalid, try to erase it
	if (_l_result == ESP_ERR_NVS_NO_FREE_PAGES)
	{

		printf("Got NO_FREE_PAGES error, trying to erase the partition...\n");

		// find the NVS partition
		const esp_partition_t* nvs_partition = esp_partition_find_first(ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_DATA_NVS, NULL);
		if(!nvs_partition) {
			printf("FATAL ERROR: No NVS partition found\n");	
			comm_system_reboot();
		}

		// erase the partition
		_l_result = (esp_partition_erase_range(nvs_partition, 0, nvs_partition->size));
		if(_l_result != ESP_OK)
		{
			printf("FATAL ERROR: Unable to erase the partition\n");
			comm_system_reboot();
		}
		printf("Partition erased!\n");

		// now try to initialize it again
		_l_result = nvs_flash_init();
		if(_l_result != ESP_OK)
		{
			printf("FATAL ERROR: Unable to initialize NVS\n");
			comm_system_reboot();
		}
	}
	printf("NVS init OK!\n");

	// open the partition in RW mode
	_l_result = nvs_open("storage", NVS_READWRITE, &g_nvmHandle);
	if (_l_result != ESP_OK)
	{
		printf("FATAL ERROR: Unable to open NVS\n");
		comm_system_reboot();
	}
}


/** @fn nvm_erase_all
 *
 * @brief This function used to erase all nvm memory
 *
 * @param void
 *.
 *  @return NA
 */
void nvm_erase_all ( void )
{
	esp_err_t _l_result = 0;

	printf("\nErasing all the VFS partition...");

	fflush(stdout);
	_l_result = nvs_erase_all(g_nvmHandle);
	if(_l_result != ESP_OK) {
		printf(" error! (%04X)\n", _l_result);
		return;
	}

	_l_result = nvs_commit(g_nvmHandle);
	if(_l_result != ESP_OK) {
		printf(" error in commit! (%04X)\n", _l_result);
		return;
	}
	printf(" done!\n");
}

/** @fn nvm_get_int
 *
 * @brief This function used to get integer value of stored parameter
 *
 * @param NA
 *.
 *  @return NA
 */
void nvm_get_int ( char* parameter, char *valueIn )
{
	int32_t value = 0;
	esp_err_t _l_result = 0;

	_l_result = nvs_get_i32(g_nvmHandle, parameter, &value);

	if(_l_result != ESP_OK) {
		if(_l_result == ESP_ERR_NVS_NOT_FOUND) printf("\nKey %s not found\n", parameter);
		else printf("\nError in nvs_get_i32! (%04X)\n", _l_result);
		return;
	}

	*valueIn = value;

	printf("\nValue stored in NVS for key %s is %d\n", parameter, value);
}

/** @fn nvm_get_string
 *
 * @brief This function used to get the value of parameter in string formate
 *
 * @param NA
 *.
 *  @return NA
 */
void nvm_get_string ( char* parameter, char *valueIn )
{
	size_t string_size;
	esp_err_t _l_result = 0;

	_l_result = nvs_get_str(g_nvmHandle, parameter, NULL, &string_size);
	if(_l_result != ESP_OK) {
		printf("\nError in nvs_get_str to get string size! (%04X)\n", _l_result);
		return;
	}

	char* strdata = malloc(string_size);

	_l_result = nvs_get_str(g_nvmHandle, parameter, strdata, &string_size);
	if(_l_result != ESP_OK) {
		///if(_l_result == ESP_ERR_NVS_NOT_FOUND) printf("\nKey %s not found\n", parameter);
		printf("\nError in nvs_get_str to get string! (%04X)\n", _l_result);
		return;
	}

	if(valueIn != NULL)
	{
		strcpy(valueIn, strdata);
	}

	printf("\nValue stored in NVS for key %s is %s\n", parameter, strdata);

	free(strdata);
}

/** @fn nvm_set_string
 *
 * @brief This function used to set the paramter value into the string formate.
 *
 * @param NA
 *.
 *  @return NA
 */
void nvm_set_string ( char* parameter, char *valueIn )
{
	esp_err_t _l_result = 0;

	_l_result = nvs_set_str(g_nvmHandle, parameter, valueIn);
	if(_l_result != ESP_OK) {
		printf("\nError in nvs_set_str! (%04X)\n", _l_result);
		return;
	}
	_l_result = nvs_commit(g_nvmHandle);
	if(_l_result != ESP_OK) {
		printf("\nError in commit! (%04X)\n", _l_result);
		return;
	}
	printf("\nValue %s stored in NVS with key %s\n", parameter, valueIn);
}

/** @fn nvm_erase_string
 *
 * @brief This function used to set the paramter value into the string formate.
 *
 * @param NA
 *.
 *  @return NA
 */
void nvm_erase_string ( char* parameter, char *valueIn )
{
	esp_err_t _l_result = 0;

	_l_result = nvs_set_str(g_nvmHandle, parameter, "\0");
	if(_l_result != ESP_OK) {
		printf("\nError in nvs_set_str! (%04X)\n", _l_result);
		return;
	}
	_l_result = nvs_commit(g_nvmHandle);
	if(_l_result != ESP_OK) {
		printf("\nError in commit! (%04X)\n", _l_result);
		return;
	}
	printf("\nValue %s stored in NVS with key \n", parameter);
}
