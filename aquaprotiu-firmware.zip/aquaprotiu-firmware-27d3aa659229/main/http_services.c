#include "common.h"
#include "http_services.h"
#include "lwip/err.h"
#include "lwip/sockets.h"
#include "lwip/sys.h"
#include "lwip/netdb.h"
#include "lwip/dns.h"
#include "json.h"

/**** Define ****************/
//#define FOTA_WEB_SERVER "fotaupdate.azurewebsites.net"
#define FOTA_WEB_SERVER "fota-update-prod.azurewebsites.net"
#define AZURE_CONNETION_WEB_SERVER "aquaproapi-dev.azurewebsites.net"
#define WEB_PORT 80
//#define FOTA_WEB_URL "https://fotaupdate.azurewebsites.net/api/GetFotaUrl?code=7Fvy2WsP1R1iIY8ce1Ie3D6ecBjypjEwRkP/WlShQJf/WcXoglatNg==&filename="

//@harshal : Added 27/05/2020 as per the requirement from Zafar
#define FOTA_WEB_URL "https://fota-update-prod.azurewebsites.net/api/GetFotaUrl?code=ClxwlyrQ4DuHUUAsPRXVybs5lM3dx3cNj1w2auunViSb290lIjkixw==&filename="
#define AZURE_CONNETION_WEB_URL "https://aquaproapi-dev.azurewebsites.net/api/HardwareRequest"

/****** All globle variabl ***********/
static const char *HTTP_TASK_TAG = "_HTTP_";
unsigned char g_http_service_stat = 0;
char g_web_url[200] = {0};
char g_http_request[1024] = {0};
char g_http_response[2048] = {0};
char g_esp_fota_download[256] = {0};
char g_mcu_fota_download[256] = {0};
char g_data[128] = {0};
int g_http_response_size;
http_info g_http_info;

//This function used to perform the POST data request
unsigned char http_perform_post_data ( void )
{
	sprintf(g_data, "{\"Time\":\"11111111\", \"SerailNumber\":\"%s\", \"UserName\":\"admin\", \"Password\":\"admin\"}", comm_get_serial_number());

	printf ("Serial Number : : [%s] [%d]\r\n", g_data, strlen(g_data));

	return STATUS_SUCCESS;
}

/** @fn http_perform_web_url
 *
 * @brief This function used to perform web url as per the input
 *
 * @param N.A.
 *.
 *  @return STATUS_SUCCESS
 */
unsigned char http_perform_web_url (unsigned char _u8device_In)
{
	char _u8local_buff[32] = {0}, _u8temp[8] = {0};

	memset (g_web_url, '\0', sizeof(g_web_url));
	do
	{
		if ( DEVICE_ID_ESP == _u8device_In )
		{
			strcpy (_u8local_buff, "AquaPro_iNemo_ESP");
			sprintf (_u8temp, "_%02d", _gst_esp_ver.major);
			strcat (_u8local_buff, _u8temp);

			memset ( _u8temp, '\0', sizeof(_u8temp));
			sprintf (_u8temp, "_%02d.bin", _gst_esp_ver.minor);
			strcat (_u8local_buff, _u8temp);

			strcpy (g_web_url, FOTA_WEB_URL);
			strcat (g_web_url, _u8local_buff);
		}
		else if ( DEVICE_ID_MCU == _u8device_In )
		{
			strcpy (_u8local_buff, "AquaPro_iNemo_MCU");
			sprintf (_u8temp, "_%02d", _gst_mcu_ver.major);
			strcat (_u8local_buff, _u8temp);

			memset ( _u8temp, '\0', sizeof(_u8temp));
			sprintf (_u8temp, "_%02d.bin", _gst_mcu_ver.minor);
			strcat (_u8local_buff, _u8temp);

			strcpy (g_web_url, FOTA_WEB_URL);
			strcat (g_web_url, _u8local_buff);
		}
		else if ( DEVICE_ID_AZURE == _u8device_In )
		{
			strcpy (g_web_url, AZURE_CONNETION_WEB_URL);
		}
		else if ( DEVICE_INVALID_ID == _u8device_In )
		{
			break;
		}
	}while (0);

	//	printf ("INFO [FOTA_WEB_URL] : %s\r\n", g_web_url);
	return STATUS_SUCCESS;
}

/** @fn http_perform_request
 *
 * @brief This function used to perform complete request
 *
 * @param N.A.
 *.
 *  @return STATUS_SUCCESS
 */
unsigned char http_perform_request ( http_info _st_httpInfo_In )
{
	unsigned char _u8local_result = STATUS_SUCCESS;
	char _u8local_buff[64] = {0};

	do
	{
		//Device ID invalid
		if ( DEVICE_INVALID_ID == _st_httpInfo_In.device_type )
		{
			_u8local_result = STATUS_ERROR;
			break;
		}

		//Perform web url
		http_perform_web_url ( _st_httpInfo_In.device_type );

		//Check request type
		if ( HTTP_GET == _st_httpInfo_In.request_type )
		{
			strcpy (g_http_request, "GET ");
		} else if ( HTTP_POST == _st_httpInfo_In.request_type ) {
			strcpy (g_http_request, "POST ");
		}

		strcat (g_http_request, g_web_url);

		strcat (g_http_request, " HTTP/1.0\r\n");

		memset (_u8local_buff, '\0', sizeof(_u8local_buff));

		if ( WEB_SERVER_AZURE == _st_httpInfo_In.web_server )
		{
			sprintf ((char*)&_u8local_buff, "Host: %s\r\n", AZURE_CONNETION_WEB_SERVER);

		}else if  ( WEB_SERVER_FOTA == _st_httpInfo_In.web_server ) {
			sprintf ((char*)&_u8local_buff, "Host: %s\r\n", FOTA_WEB_SERVER);
		}

		strcat (g_http_request, _u8local_buff);

		memset (_u8local_buff, '\0', sizeof(_u8local_buff));

		if ( HTTP_POST == _st_httpInfo_In.request_type)
		{
			sprintf ((char*)&_u8local_buff, "Content-Length: %d\r\n", strlen(g_data));
			strcat (g_http_request, _u8local_buff);
		}

		strcat(g_http_request, "\r\n");

	}while (0);

//	printf ("<<<<<<<<<< INFO : %s >>>>>>>>>>>>>\r\n",g_http_request);
	return _u8local_result;
}

//This function used to process the response
unsigned char http_process_response (unsigned char _u8RespTag_In)
{
	char *pStr = NULL, _u8local_result = STATUS_ERROR;

	bzero(g_mcu_fota_download, sizeof(g_mcu_fota_download));
	bzero(g_esp_fota_download, sizeof(g_esp_fota_download));
	switch (_u8RespTag_In)
	{
		case RES_UPDATE_ESP_FOTA_STRING:
			pStr = strstr(g_http_response, "https://aqupro");
			if ( NULL != pStr)
			{
				strcpy(g_esp_fota_download, pStr);
				_u8local_result = STATUS_SUCCESS;
			}else{
				printf ("[ERROR] : Download string not found\r\n");
			}
			break;

		case RES_UPDATE_MCU_FOTA_STRING:
			pStr = strstr(g_http_response, "https://aqupro");
			if ( NULL != pStr)
			{
				strcpy(g_mcu_fota_download, pStr);
				_u8local_result = STATUS_SUCCESS;
			}else{
				printf ("[ERROR] : Download string not found\r\n");
			}
			break;

		case RES_UPDATE_CONNECTION_STRING:
			pStr = strstr(g_http_response, "{\"response\"");
			if ( NULL != pStr)
			{
				if ( STATUS_SUCCESS == GetStringFromTag(pStr, (char*)&_gu8ConnectoinString, "devicePrimaryConnectionString"))
				{
					printf ("Connection String : %s\r\n", _gu8ConnectoinString);
				} else {
					printf ("[ERROR] : \"devicePrimaryConnectionString\" Tag not found\r\n");
				}
			} else {
				printf ("[ERROR] : Connection string not found\r\n");
			}
			break;

		default:
			printf ("[ERROR] : Wrong Response Tag received\r\n");
			break;
	}
	printf ("INFO :: ::: Status %d \r\n", _u8local_result);
	return _u8local_result;
}

//This function used to send query and get response
unsigned char http_send_query_get_resp( http_info _st_httpInfo_In )
{
	const struct addrinfo hints = {
		.ai_family = AF_INET,
		.ai_socktype = SOCK_STREAM,
	};
	struct addrinfo *res;
	struct in_addr *addr;
	int s, r;
	int _u32_error_code = 0, _u32itr, j;
	int _u32total_recv = 0;
	unsigned char _u8RetryCount = 0, _u8local_result = 0;
	char _u8localBuff[512] = {0};

	http_perform_post_data();
	//Perform the request as per the input
	memset ( g_http_request, '\0', sizeof(g_http_request) );
	http_perform_request ( _st_httpInfo_In );

	while( _u8RetryCount < 3 )
	{
		//get address info of web server
		if ( WEB_SERVER_FOTA == _st_httpInfo_In.web_server )
		{
			_u32_error_code = getaddrinfo(FOTA_WEB_SERVER, "80", &hints, &res);

		} else if ( WEB_SERVER_AZURE == _st_httpInfo_In.web_server ) {
			_u32_error_code = getaddrinfo(AZURE_CONNETION_WEB_SERVER, "80", &hints, &res);
		}

		if(_u32_error_code != 0 || res == NULL)
		{
			ESP_LOGE(HTTP_TASK_TAG, "DNS lookup failed err=%d res=%p", _u32_error_code, res);
			vTaskDelay(1000 / portTICK_PERIOD_MS);
			_u8RetryCount++;
			_u8local_result = STATUS_ERROR;
			continue;
		}

		/* Code to print the resolved IP.
		 *    Note: inet_ntoa is non-reentrant, look at ipaddr_ntoa_r for "real" code */
		addr = &((struct sockaddr_in *)res->ai_addr)->sin_addr;
		ESP_LOGI(HTTP_TASK_TAG, "DNS lookup succeeded. IP=%s", inet_ntoa(*addr));

		//Create socket connection
		s = socket(res->ai_family, res->ai_socktype, 0);
		if(s < 0)
		{
			ESP_LOGE(HTTP_TASK_TAG, "... Failed to allocate socket.");
			freeaddrinfo(res);
			vTaskDelay(1000 / portTICK_PERIOD_MS);
			_u8RetryCount++;
			_u8local_result = STATUS_ERROR;
			continue;
		}

		ESP_LOGI(HTTP_TASK_TAG, "... allocated socket");

		//Connect to address
		if(connect(s, res->ai_addr, res->ai_addrlen) != 0)
		{
			ESP_LOGE(HTTP_TASK_TAG, "... socket connect failed errno=%d", errno);
			close(s);
			freeaddrinfo(res);
			vTaskDelay(4000 / portTICK_PERIOD_MS);
			_u8RetryCount++;
			_u8local_result = STATUS_ERROR;
			continue;
		}

		ESP_LOGI(HTTP_TASK_TAG, "... connected");
		//Free Address Info
		freeaddrinfo(res);

		//Write request to the server
		//        printf ("INFO :::: %s || strlen %d\r\n", REQUEST, strlen(REQUEST));
		if (write(s, g_http_request, strlen(g_http_request)) < 0)
		{
			ESP_LOGE(HTTP_TASK_TAG, "... socket send failed");
			close(s);
			vTaskDelay(4000 / portTICK_PERIOD_MS);
			_u8RetryCount++;
			_u8local_result = STATUS_ERROR;
			continue;
		}
		ESP_LOGI(HTTP_TASK_TAG, "... socket send success");

		if ( HTTP_POST == _st_httpInfo_In.request_type)
		{
			if (write(s, g_data, strlen(g_data)) < 0)
				//			if (write(s, DATA, strlen(DATA)) < 0)
			{
				ESP_LOGE(HTTP_TASK_TAG, "... socket send failed");
				close(s);
				vTaskDelay(4000 / portTICK_PERIOD_MS);
				_u8RetryCount++;
				_u8local_result = STATUS_ERROR;
				continue;
			}
		}


		struct timeval receiving_timeout;
		receiving_timeout.tv_sec = 10;
		receiving_timeout.tv_usec = 0;

		//Set socket received timeout
		if (setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &receiving_timeout, sizeof(receiving_timeout)) < 0)
		{
			ESP_LOGE(HTTP_TASK_TAG, "... failed to set socket receiving timeout");
			close(s);
			vTaskDelay(4000 / portTICK_PERIOD_MS);
			_u8RetryCount++;
			_u8local_result = STATUS_ERROR;
			continue;
		}

		ESP_LOGI(HTTP_TASK_TAG, "... set socket receiving timeout success");

		/* Read HTTP response */
		_u32total_recv = 0;
		_u32itr = 0;
		bzero(g_http_response, sizeof(g_http_response));
		do
		{
			bzero(_u8localBuff, sizeof(_u8localBuff));
			r = read(s, _u8localBuff, sizeof(_u8localBuff)-1);

			_u32total_recv += r;
			//            printf ("<<<< %d >>>>\r\n",_u32total_recv);
			for( j = 0; j < r ; j++,_u32itr++)
			{
				g_http_response[_u32itr] = _u8localBuff[j];
				putchar(_u8localBuff[j]);
			}
		} while(r > 0);

		g_http_response_size = _u32total_recv;

		ESP_LOGI(HTTP_TASK_TAG, "... done reading from socket. Last read return=%d errno=%d\r\n", r, errno);
		close(s);
		_u8local_result = STATUS_SUCCESS;
		break;
	}

	if ( STATUS_SUCCESS == _u8local_result )
	{
		if (DEVICE_ID_ESP == _st_httpInfo_In.device_type){
			printf ("Response : %s\r\n",g_http_response);
			http_process_response(RES_UPDATE_ESP_FOTA_STRING);

		}else if (DEVICE_ID_MCU == _st_httpInfo_In.device_type){
			http_process_response(RES_UPDATE_MCU_FOTA_STRING);

		} else if (DEVICE_ID_AZURE == _st_httpInfo_In.device_type){
			http_process_response(RES_UPDATE_CONNECTION_STRING);
		}
	}

	return _u8local_result;
}

//Test fucntion
unsigned char test ( void )
{
	http_info _st_httpInfo_In;
	_st_httpInfo_In.device_type = DEVICE_ID_ESP;
	_st_httpInfo_In.request_type = HTTP_GET;

	if ( STATUS_SUCCESS == http_send_query_get_resp(_st_httpInfo_In))
	{
		printf("ESP DOWNLOAD STRING  : %s\r\n", g_esp_fota_download);
	}

	vTaskDelay(10000 / portTICK_PERIOD_MS);

	_st_httpInfo_In.device_type = DEVICE_ID_MCU;
	_st_httpInfo_In.request_type = HTTP_POST;

	if ( STATUS_SUCCESS == http_send_query_get_resp(_st_httpInfo_In))
	{
		printf("MCU DOWNLOAD STRING  : %s\r\n", g_mcu_fota_download);
	}

	return 1;
}
