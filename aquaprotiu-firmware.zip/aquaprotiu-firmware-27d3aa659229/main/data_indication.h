#ifndef _DATA_INDICATION_H_
#define _DATA_INDICATION_H_

void data_indication_service (void *pvParameter);

#endif
