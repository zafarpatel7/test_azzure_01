#include "iothub_client.h"
#include "iothub_device_client_ll.h"
#include "iothub_client_options.h"
#include "iothub_message.h"
#include "azure_c_shared_utility/threadapi.h"
#include "azure_c_shared_utility/crt_abstractions.h"
#include "azure_c_shared_utility/platform.h"
#include "azure_c_shared_utility/shared_util_options.h"
#include "iothubtransportmqtt.h"
#include "iothub_client_options.h"
#include "azure_comm.h"
#include "common.h"
#include "flash.h"
#include "http_services.h"
#include "json.h"

/**** Define ****************/
#define AZUR_INIT_MAX_RETRY_COUNT (3)
#define AZURE_PACKET_MIN_TIME (-20)
#define AZURE_PACKET_MAX_TIME (50)
//If you want packet validation then set following flag as 1 else 0
#define AZURE_PACKET_VALIDATION (0)
#define MESSAGE_COUNT (0xFFFFFFFF)
#define DOWORK_LOOP_NUM     3

/****** All globle variabl ***********/
static const char *Azure_TASK_TAG = "_Azure_";
static int g_azure_connection_status = COMM_AZURE_DISCONNECTED;
static int callbackCounter;
static char msgText[1024];
static bool g_Power_On = 0;
static unsigned char _gu8_platform_init_count = 0;
char gDataForController[512];
bool gSendDataToController = false;
static unsigned char _gu8AzureCommand = AZURE_NO_PACKET;
int _gu32iterator = 0;
time_t _gu8sent_time = 0;
time_t _gu8current_time = 0;
azure_stat_machine g_azure_service_stat;
azure_stat_machine g_azure_current_valid_stat;

/********** All extern variable *******/
extern unsigned char g_send_data_to_cloud;
extern char g_cloud_data[512];
extern int _gu32ErrorCode;

/********** Structure ************/
typedef struct EVENT_INSTANCE_TAG
{
	IOTHUB_MESSAGE_HANDLE messageHandle;
	size_t messageTrackingId;  // For tracking the messages within the user callback.
} EVENT_INSTANCE;

IOTHUB_CLIENT_LL_HANDLE azure_IoTHandle;
EVENT_INSTANCE message;

/** @fn azure_get_connection_status
 *
 * @brief This function used to get the azure connection status
 *
 *  @return Current azure connection status
 */
int azure_get_connection_status ( void )
{
	return g_azure_connection_status;
}

/** @fn azure_set_connection_status
 *
 * @brief This function used to set the Azure connection status
 *
 * @param val_In : Connection status In
 *
 *  @return None
 */
void azure_set_connection_status ( int val_In)
{
	g_azure_connection_status = val_In;
}

/** @fn azure_set_valid_stat
 *
 * @brief This function used to set the valid stat of the azure
 *
 * @param _u8state_In : valid stat
 *
 *  @return None
 */
void azure_set_valid_stat ( unsigned char _u8stat_In )
{
	g_azure_current_valid_stat = _u8stat_In;
}

/** @fn azure_get_valid_stat
 *
 * @brief This function used to get the valid stat of azure
 *
 *  @return Azure valid stat
 */
unsigned char azure_get_valid_stat ( void )
{
	return g_azure_current_valid_stat;
}


/** @fn azure_send_command
 *
 * @brief This function used to send command to azure
 *
 * @param Change the state
 *
 *  @return None
 */
void azure_send_command (unsigned char _u8azure_command_In)
{
	printf ("_gu8AzureCommand :: %d\r\n", _gu8AzureCommand);
	while ( _gu8AzureCommand != AZURE_NO_PACKET )
	{
		vTaskDelay(20 / portTICK_PERIOD_MS);
	}
	_gu8AzureCommand = _u8azure_command_In;
}

/** @fn azure_set_state
 *
 * @brief This function used to change azure service state
 *
 * @param Change the state
 *
 *  @return None
 */
void azure_set_state ( unsigned char _u8stat_in )
{
	g_azure_service_stat = _u8stat_in;
}

/** @fn azure_get_state
 *
 * @brief This function used to get current state of the azure service
 *
 * @param N.A.
 *.
 *  @return None.
 */
unsigned char azure_get_state ( void )
{
	return g_azure_service_stat;
}

/** @fn azure_validate_fota_command
 *
 * @brief This function used to validate the FOTA command received from azure
 *
 * @param
 *.
 *  @return SUCCESS.
 */
unsigned char azure_validate_fota_command (const char *_u8buffer_in, unsigned char *_u8esp_status_out, unsigned char *_u8mcu_status_out)
{
	fw_version _local_ver;

	char *_pu8_local = NULL;
	char _u8esp_ver[6]={0}, _u8mcu_ver[6]={0}, _u8major[3]={0}, _u8min[3] = {0};

	if(_u8buffer_in == NULL)
		return STATUS_ERROR;

	printf("FW Version [IN validation] : %s\n", _u8buffer_in);
	_pu8_local = (char*)_u8buffer_in;

	strncpy(_u8esp_ver, _pu8_local, 5);

	printf("INFO [ VALIDATE ] : MCU VErsion : %s \r\n",_u8esp_ver);
	strncpy(_u8major, _u8esp_ver, 2);
	_u8major[2] = '\0';
	strncpy(_u8min, &_u8esp_ver[3], 2);
	_u8min[2] = '\0';
	_gst_mcu_ver.major = atoi(_u8major);
	_gst_mcu_ver.minor = 	atoi(_u8min);

	memset(_u8major, '\0', sizeof (_u8major));
	memset(_u8min, '\0', sizeof (_u8min));

	_pu8_local = _pu8_local + 6;

	strncpy(_u8mcu_ver, _pu8_local, 5);
	strncpy(_u8major, _u8mcu_ver, 2);
	_u8major[2] = '\0';
	strncpy(_u8min, &_u8mcu_ver[3], 2);
	_u8min[2] = '\0';
	_gst_esp_ver.major = atoi(_u8major);
	_gst_esp_ver.minor = atoi(_u8min);


	//Get ESP version from Flash
	memset(_u8major, '\0', sizeof (_u8major));
	memset(_u8min, '\0', sizeof (_u8min));
	nvm_get_string (ESP_VER_MAJOR, _u8major);
	nvm_get_string (ESP_VER_MINOR, _u8min);
	_local_ver.major = atoi(_u8major);
	_local_ver.minor = atoi(_u8min);

	if (  STATUS_SUCCESS == comm_version_compare (_gst_esp_ver, _local_ver))
	{
		//NOTE : Both version not same
		*_u8esp_status_out = 1; //Set 1
	}

	//Get MCU version from Flash
	memset(_u8major, '\0', sizeof (_u8major));
	memset(_u8min, '\0', sizeof (_u8min));
	nvm_get_string (MCU_VER_MAJOR, _u8major);
	nvm_get_string (MCU_VER_MINOR, _u8min);
	memset(&_local_ver, '\0', sizeof(_local_ver));
	_local_ver.major = atoi(_u8major);
	_local_ver.minor = atoi(_u8min);

	if (  STATUS_SUCCESS == comm_version_compare (_gst_mcu_ver, _local_ver))
	{
		//NOTE : Both version not same
		*_u8mcu_status_out = 1; //Set 1
	}

	return STATUS_SUCCESS;
}


/** @fn azure_ReceiveMessageCallback
 *
 * @brief This function used to receive the message from Azure
 *
 *  @return SUCCESS.
 */
static IOTHUBMESSAGE_DISPOSITION_RESULT azure_ReceiveMessageCallback(IOTHUB_MESSAGE_HANDLE message, void* userContextCallback)
{
	int* counter = (int*)userContextCallback;
	const char* buffer;
	size_t size;
	MAP_HANDLE mapProperties;
	const char* messageId;
	const char* correlationId;
	unsigned char _u8esp_ver=0, _u8mcu_ver=0;
	int _u32State = 0;
#if AZURE_PACKET_VALIDATION
	time_t _timediff = 0;
	time_t packettime = 0;
#endif
	char *ptr = NULL;


	// Message properties
	if ((messageId = IoTHubMessage_GetMessageId(message)) == NULL)
	{
		messageId = "<null>";
	}

	if ((correlationId = IoTHubMessage_GetCorrelationId(message)) == NULL)
	{
		correlationId = "<null>";
	}

	// Message content
	if (IoTHubMessage_GetByteArray(message, (const unsigned char**)&buffer, &size) != IOTHUB_MESSAGE_OK)
	{
		(void)printf("unable to retrieve the message data\r\n");
	}
	else
	{
		if(buffer != NULL)
		{
			(void)printf("Received Message Data: <<<%s>>> & Size=%d\r\n", buffer, (int)size);

			do
			{
				//Load buffer into json object
				//Create JSON Object
				cJSON *proot = cJSON_Parse(buffer);

				if (proot == NULL)
				{
					while ( gSendDataToController == true )
					{
						vTaskDelay(50 / portTICK_PERIOD_MS);
					}
					//INVALID_JSON_RECEIVED;
					memset(gDataForController, '\0', sizeof(gDataForController));
					strcpy(gDataForController, INVALID_JSON);
					size = strlen(gDataForController);
					gDataForController[size] = 0x0D;
					gDataForController[size+1] = 0x0A;
					gSendDataToController = true;
					break;
				} else {
					//Process Response
#if AZURE_PACKET_VALIDATION
					//Get Time Stamp
					ptr = (char *)cJSON_GetObjectItem(proot, "TIME")->valuestring;
					if (ptr != NULL)
					{
						//Convert string into Epoch time
						packettime = (time_t)atoi(ptr);

						printf ("Packet Time : %lu\n", packettime);

						//Get Local Time
						time(&_gu8current_time);
						_timediff = difftime(_gu8current_time, packettime);

						printf ("Time Diff : %lu\n", _timediff);

						if(_timediff < AZURE_PACKET_MAX_TIME && _timediff > AZURE_PACKET_MIN_TIME)
						{
							printf ("Valid Packet Received\n");
						}
						else
						{
							printf ("Invalid Packet Received\n");
							while ( gSendDataToController == true )
							{
								vTaskDelay(50 / portTICK_PERIOD_MS);
							}
							//INVALID_JSON_RECEIVED;
							memset(gDataForController, '\0', sizeof(gDataForController));
							strcpy(gDataForController, INVALID_JSON);
							size = strlen(gDataForController);
							gDataForController[size] = 0x0D;
							gDataForController[size+1] = 0x0A;
							gSendDataToController = true;
							break;
						}
					}
#endif
					//******* Check which ID received **********//
					ptr = (char *)cJSON_GetObjectItem(proot, "ID");
					if (ptr == NULL)
					{
						printf ("Invalid Packet Received\n");
						while ( gSendDataToController == true )
						{
							vTaskDelay(50 / portTICK_PERIOD_MS);
						}
						memset(gDataForController, '\0', sizeof(gDataForController));
						memcpy(gDataForController, buffer, size);
						gDataForController[size] = 0x0D;
						gDataForController[size+1] = 0x0A;
						gSendDataToController = true;
						break;

					} else {
						ptr = (char *)cJSON_GetObjectItem(proot, "ID")->valuestring;
						if (ptr != NULL)
						{
							if (strcmp(ptr, FOTA_PACKET_ID) == 0)
							{
								_u32State = comm_get_service_state( FOTA_SERVICE_BIT );

								if ( FOTA_WAIT == _u32State)
								{
									ptr = (char *)cJSON_GetObjectItem(proot, "FW_VER")->valuestring;
									if (ptr != NULL)
									{
										printf("FW Version : %s\n", ptr);
										azure_validate_fota_command (ptr, &_u8esp_ver, &_u8mcu_ver );

										printf ("INFO ::: ESP_VER : %d || MCU_VER : %d \r\n", _u8esp_ver, _u8mcu_ver);
										if ( (1 ==_u8esp_ver) && (1 ==_u8mcu_ver) )
										{
											//Send BOTH FOTA received event
											xEventGroupSetBits(g_xServiceStatEventGroup, COMM_START_BOTH_FOTA );
											//Update Error Code
											_gu32ErrorCode = FOTA_GOING_TO_FOTA;
											xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_FOTA_ACK );

										}else if ( 1 == _u8esp_ver ){
											//Send ESP FOTA received event
											xEventGroupSetBits(g_xServiceStatEventGroup, COMM_START_ESP_FOTA );
											//Update Error Code
											_gu32ErrorCode = FOTA_GOING_TO_FOTA;
											xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_FOTA_ACK );

										}else if ( 1 ==_u8mcu_ver ){
											//Send MCU FOTA received event
											xEventGroupSetBits(g_xServiceStatEventGroup, COMM_START_MCU_FOTA );
											//Update Error Code
											_gu32ErrorCode = FOTA_GOING_TO_FOTA;
											xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_FOTA_ACK );

										} else {
											ESP_LOGI(Azure_TASK_TAG, "ESP [%d.%d] and MCU [%d:%d] version are same", _gst_esp_ver.major, _gst_esp_ver.minor, _gst_mcu_ver.major, _gst_mcu_ver.minor);
											//Update Error Code
											_gu32ErrorCode = FOTA_ALREADY_UPDATED;
											xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_FOTA_ACK );
										}
									}
									else
									{
										printf ("Invalid Packet Received\n");
										while ( gSendDataToController == true )
										{
											vTaskDelay(50 / portTICK_PERIOD_MS);
										}
										//INVALID_JSON_RECEIVED;
										memset(gDataForController, '\0', sizeof(gDataForController));
										strcpy(gDataForController, INVALID_JSON);
										size = strlen(gDataForController);
										gDataForController[size] = 0x0D;
										gDataForController[size+1] = 0x0A;
										gSendDataToController = true;
										break;
									}
								} else {
									ESP_LOGI(Azure_TASK_TAG, "FOTA is in progress ... ");
								}
							} else {
								//Send data to the MCU
								//Wait here if any command is in progress
								while ( gSendDataToController == true )
								{
									vTaskDelay(50 / portTICK_PERIOD_MS);
								}

								memset(gDataForController, '\0', sizeof(gDataForController));
								memcpy(gDataForController, buffer, size);
								gDataForController[size] = 0x0D;
								gDataForController[size+1] = 0x0A;
								gSendDataToController = true;

							}
						}
					}
				}
			}while(0);

			if (gSendDataToController == true)
			{
				//Send azure to MCU data event
				xEventGroupSetBits(g_xServiceStatEventGroup, COMM_SEND_DATA_TO_MCU );
			}
		}
	}

	// Retrieve properties from the message
	mapProperties = IoTHubMessage_Properties(message);
	if (mapProperties != NULL)
	{
		const char*const* keys;
		const char*const* values;
		size_t propertyCount = 0;

		if (Map_GetInternals(mapProperties, &keys, &values, &propertyCount) == MAP_OK)
		{
			if (propertyCount > 0)
			{
				size_t index;

				printf(" Message Properties:\r\n");
				for (index = 0; index < propertyCount; index++)
				{
					(void)printf("\tKey: %s Value: %s\r\n", keys[index], values[index]);
				}
				(void)printf("\r\n");
			}
		}
	}

	/* Some device specific action code goes here... */
	(*counter)++;
	return IOTHUBMESSAGE_ACCEPTED;
}

/** @fn azure_SendConfirmationCallback
 *
 * @brief This is a callback function used for Send Data Confirmation
 *
 * @param N.A.
 *.
 *  @return None.
 */
static void azure_SendConfirmationCallback(IOTHUB_CLIENT_CONFIRMATION_RESULT result, void* userContextCallback)
{
	EVENT_INSTANCE* eventInstance = (EVENT_INSTANCE*)userContextCallback;
	size_t id = eventInstance->messageTrackingId;

	if (result == IOTHUB_CLIENT_CONFIRMATION_OK) {
		(void)printf("Confirmation[%d] received for message tracking id = %d with result = %s\r\n", callbackCounter, (int)id, ENUM_TO_STRING(IOTHUB_CLIENT_CONFIRMATION_RESULT, result));
		/* Some device specific action code goes here... */
		callbackCounter++;
	}
	else if ( result == IOTHUB_CLIENT_CONFIRMATION_MESSAGE_TIMEOUT)
	{
		ESP_LOGI(Azure_TASK_TAG, "**** Send Confirmation : IOTHUB_CLIENT_CONFIRMATION_MESSAGE_TIMEOUT ****");
		xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_CHANGE_CSTR_REQ );
	}
	else if ( result == IOTHUB_CLIENT_CONFIRMATION_BECAUSE_DESTROY)
	{
		ESP_LOGI(Azure_TASK_TAG, "**** Send Confirmation : IOTHUB_CLIENT_CONFIRMATION_BECAUSE_DESTROY ****");
	}
	else if ( result == IOTHUB_CLIENT_CONFIRMATION_ERROR )
	{
		ESP_LOGI(Azure_TASK_TAG, "**** Send Confirmation : IOTHUB_CLIENT_CONFIRMATION_ERROR ****");
	}

	g_send_data_to_cloud = 0;
	IoTHubMessage_Destroy(eventInstance->messageHandle);
}

/** @fn azure_conn_status_callback
 *
 * @brief This function used to 
 *
 * @param N.A.
 *.
 *  @return None.
 */
void azure_conn_status_callback(IOTHUB_CLIENT_CONNECTION_STATUS result, IOTHUB_CLIENT_CONNECTION_STATUS_REASON reason, void* userContextCallback)
{
	(void)printf("\n\nConnection Status result:%s, Connection Status reason: %s\n\n", ENUM_TO_STRING(IOTHUB_CLIENT_CONNECTION_STATUS, result),
			ENUM_TO_STRING(IOTHUB_CLIENT_CONNECTION_STATUS_REASON, reason));

	if(IOTHUB_CLIENT_CONNECTION_OK == reason)
	{
		printf ("******* CLIENT CONNECTION OK RECEIVED **********\r\n");
		azure_set_connection_status( COMM_AZURE_CONNECTED );
		xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_CONNECTED);		
	}
	else if( IOTHUB_CLIENT_CONNECTION_BAD_CREDENTIAL == reason)
	{
		printf ("******* BAD CREDENTIAL RECEIVED **********\r\n");
	}
	else if( IOTHUB_CLIENT_CONNECTION_DEVICE_DISABLED == reason)
	{
		printf ("******* DEVICE DISABLED RECEIVED **********\r\n");
		azure_set_connection_status( COMM_AZURE_DISCONNECTED );
		xEventGroupSetBits(g_xServiceStatEventGroup, COMM_AZURE_DISCONNECTED);		
	}
	else if ( IOTHUB_CLIENT_CONNECTION_NO_NETWORK == reason )
	{
		printf ("******* NO NETWORK RECEIVED **********\r\n");
	}
	else if ( IOTHUB_CLIENT_CONNECTION_COMMUNICATION_ERROR == reason)
	{
		printf ("******* CONNECTION ERROR RECEIVED **********\r\n");
	}
	/*else if (IOTHUB_CLIENT_CONNECTION_NO_PING_RESPONSE == reason )
	{
		printf ("******* BAD CREDENTIAL RECEIVED **********\r\n");
	}*/
	else if (IOTHUB_CLIENT_CONNECTION_EXPIRED_SAS_TOKEN == reason)
	{
		printf ("******* SAS TOKEN EXPIRE RECEIVED **********\r\n");
	}
	else if (IOTHUB_CLIENT_CONNECTION_RETRY_EXPIRED == reason)
	{
		printf ("******* CONNECTION RETRY EXPIRED RECEIVED **********\r\n");
	}

}

/** @fn azure_iothub_platform_deinit
 *
 * @brief This function used to deinit azure platform
 *
 * @param N.A.
 *.
 *  @return None.
 */
void azure_iothub_platform_deinit(void)
{
	(void)printf("iothub_client_sample_mqtt has gotten quit message, call DoWork %d more time to complete final sending...\r\n", DOWORK_LOOP_NUM);
	size_t index = 0;
	for (index = 0; index < DOWORK_LOOP_NUM; index++)
	{
		if(azure_IoTHandle != NULL)
			IoTHubClient_LL_DoWork(azure_IoTHandle);
		ThreadAPI_Sleep(1);
	}

	if(azure_IoTHandle != NULL)
		IoTHubClient_LL_Destroy(azure_IoTHandle);

	_gu8sent_time = 0;
	_gu32iterator = 0;
	platform_deinit();
}

/** @fn azure_check_HB_time
 *
 * @brief This function compare current time with last packet send time
 *
 * @param N.A.
 *.
 *  @return SUCCESS on HB Time overflow Else FALSE
 */
unsigned char azure_check_HB_time (time_t _currentTime, time_t _lastPacketTime )
{
	time_t _timediff = 0;

	_timediff = difftime(_currentTime, _lastPacketTime);

	if (_timediff >= ((CONFIG_MESSAGE_INTERVAL_TIME) / 1000))
		return 1;

	//	printf ("INFO : HB Time [%lu]\r\n", _timediff);

	return 0;
}

/** @fn azure_start_iothub
 *
 * @brief This function used to start the "azure_start_iothub"
 *
 * @param N.A.
 *.
 *  @return None.
 */
void azure_start_iothub( unsigned char _u8Command_In )
{	
	unsigned char _u8SendMsg = 0, _u8lHBtime = 0;
	const esp_app_desc_t *appInfo = NULL;
	char _u8major[3] = {0}, _u8minor[3] = {0};
	tcpip_adapter_ip_info_t ipinfo;
	unsigned char mac[6] = {0};
	char _u8Pend[3] = {0};

	time(&_gu8current_time);

	_u8lHBtime = azure_check_HB_time (_gu8current_time, _gu8sent_time);

	if(_u8lHBtime && (_u8Command_In == AZURE_NO_PACKET))
	{
		_u8Command_In = AZURE_HEART_BEAT_PACKET;
	}

	if (((MESSAGE_COUNT == 0 || _gu32iterator < MESSAGE_COUNT)
			&& _gu32iterator <= callbackCounter))
	{
		switch (_u8Command_In)
		{
		case AZURE_DATA_PACKET:
			sprintf_s(msgText, sizeof(msgText), "%s\r\n",g_cloud_data);
			//				g_send_data_to_cloud = 0;
			(void)printf("** INFO : Message : %s **\r\n",msgText);
			_u8SendMsg = 1;
			break;

		case AZURE_POWERON_PACKET:
			//Get Application version
			appInfo = esp_ota_get_app_description();
			wifi_ap_record_t _wifiInfo;
			esp_wifi_sta_get_ap_info(&_wifiInfo);
			//Update ESP version into the flash here
			strncpy( _u8major, appInfo->version, 2);
			strncpy( _u8minor, &appInfo->version[3], 2);
			nvm_set_string (ESP_VER_MAJOR, _u8major);
			nvm_set_string (ESP_VER_MINOR, _u8minor);

			memset(_u8major, '\0', sizeof(_u8major));
			memset(_u8minor, '\0', sizeof(_u8minor));
			nvm_get_string (MCU_VER_MAJOR, _u8major);
			nvm_get_string (MCU_VER_MINOR, _u8minor);

			//Get IP Address
			ESP_ERROR_CHECK(tcpip_adapter_get_ip_info(TCPIP_ADAPTER_IF_STA, &ipinfo));

			ESP_ERROR_CHECK(esp_read_mac(mac, ESP_MAC_WIFI_STA));

			//Power On Packet need to be create
			sprintf_s(msgText, sizeof(msgText), "{\"DID\":\"%s\",\"PID\":\"%d\",\"ID\":\"12\",\"TIME\":\"%lu\",\"PF\":0, \"FW_VER\":\"%s.%s.%s\", \"RSSI\":\"%d\", \"LIP\":\""IPSTR"\", \"MAC\":\"%02x:%02x:%02x:%02x:%02x:%02x\"}\r\n",
					comm_get_serial_number(), (_gu32iterator+1), _gu8current_time, _u8major, _u8minor, appInfo->version, _wifiInfo.rssi,IP2STR(&ipinfo.ip),mac[0], mac[1],mac[2],mac[3],mac[4],mac[5]);
			(void)printf("** INFO : Message : %s **\r\n",msgText);
			g_Power_On = 1;
			_u8SendMsg = 1;
			break;

		case AZURE_HEART_BEAT_PACKET:
			//heart beat packet need to be create
			sprintf_s(msgText, sizeof(msgText), "{\"DID\":\"%s\",\"PID\":\"%d\",\"TIME\":\"%lu\"}\r\n", comm_get_serial_number(), (_gu32iterator+1), _gu8current_time);
			(void)printf("** INFO : Message : %s **\r\n",msgText);
			_u8SendMsg = 1;
			break;

		case AZURE_FOTA_REQUEST:
			sprintf_s(msgText, sizeof(msgText), "{\"DID\":\"%s\",\"PID\":\"%d\",\"ID\":\"A6\",\"TIME\":\"%lu\",\"FW_VER\":\"FOTA\"}\r\n", comm_get_serial_number(), (_gu32iterator+1), _gu8current_time);
			(void)printf("** INFO : Message : %s **\r\n",msgText);
			_u8SendMsg = 1;
			break;

		case AZURE_FOTA_ACK:
			sprintf_s(msgText, sizeof(msgText), "{\"DID\":\"%s\",\"PID\":\"%d\",\"ID\":\"AC\",\"TIME\":\"%lu\",\"ACK\":\"%d\"}\r\n", comm_get_serial_number(), (_gu32iterator+1), _gu8current_time, _gu32ErrorCode);
			(void)printf("** INFO : Message : %s **\r\n",msgText);
			_u8SendMsg = 1;
			break;

		case AZURE_NO_PACKET:
		default:
			break;
		}

		//Set default command after execution of received command
		_gu8AzureCommand = AZURE_NO_PACKET;

		//Check Pending FOTA flag in each power on
		if (AZURE_POWERON_PACKET == _u8Command_In)
		{
			//Get FOTA Pending flag
			nvm_get_string (FOTA_PENDING_STATUS, _u8Pend);
			if (0 == strcmp(_u8Pend, "1"))
			{
				azure_send_command( AZURE_FOTA_REQUEST );
			}
		}

		if (_u8SendMsg)
		{
			if ((message.messageHandle = IoTHubMessage_CreateFromByteArray((const unsigned char*)msgText, strlen(msgText))) == NULL)
			{
				(void)printf("ERROR: iotHubMessageHandle is NULL!\r\n");
			}
			else
			{
				message.messageTrackingId = _gu32iterator;
				if (IoTHubClient_LL_SendEventAsync(azure_IoTHandle, message.messageHandle, azure_SendConfirmationCallback, &message) != IOTHUB_CLIENT_OK)
				{
					(void)printf("ERROR: IoTHubClient_LL_SendEventAsync..........FAILED!\r\n");
				}
				else
				{
					time(&_gu8sent_time);
					(void)printf("IoTHubClient_LL_SendEventAsync accepted message [%d] for transmission to IoT Hub.\r\n", (int)_gu32iterator);
				}
				_gu32iterator++;
			}
		}	
	}

	IoTHubClient_LL_DoWork(azure_IoTHandle);
	ThreadAPI_Sleep(100);
}

/** @fn azure_platform_init
 *
 * @brief This function used to init azure platform
 *
 * @param N.A.
 *.
 *  @return None.
 */
unsigned char azure_platform_init ( void ) 
{
	unsigned char _u8result = 1;
	int receiveContext = 0;

	printf("**** In Azure Platform Init ****\r\n");
	do
	{
		if (platform_init() != 0)
		{
			//Fail
			_u8result = 0;
		}else{
			if ((azure_IoTHandle = IoTHubClient_LL_CreateFromConnectionString(_gu8ConnectoinString, MQTT_Protocol)) == NULL)
			{
				(void)printf("ERROR: azure_IoTHandle is NULL!\r\n");
				//Fail
				_u8result = 0;
			}
			else
			{
				bool traceOn = true;
				//Enable Log Trace
				IoTHubClient_LL_SetOption(azure_IoTHandle, OPTION_LOG_TRACE, &traceOn);

				//Set the callback for connection status
				ESP_ERROR_CHECK ( IoTHubClient_LL_SetConnectionStatusCallback(azure_IoTHandle, azure_conn_status_callback, NULL));

				/* Setting Message call back, so we can receive Commands. */
				// Set the callback for receive message from Azure server
				if (IoTHubClient_LL_SetMessageCallback(azure_IoTHandle, azure_ReceiveMessageCallback, &receiveContext) != IOTHUB_CLIENT_OK)
				{
					(void)printf("ERROR: IoTHubClient_LL_SetMessageCallback..........FAILED!\r\n");
					_u8result = 0;
				}
			}
		}
	}while (0);

	srand((unsigned int)time(NULL));
	callbackCounter = 0; 
	//	printf("**** Out Azure Platform Init [%d]****\r\n",_u8result);
	return _u8result;
}

/** @fn azure_service
 *
 * @brief This function used to start azure service
 *
 * @param N.A.
 *.
 *  @return None.(Will not Return from here.)
 */
void azure_service (void *pvParameter)
{
	EventBits_t _u32xevent_result;
	unsigned char _u8result = 0;
	http_info _st_httpInfo_In;
	char _u8localSerialNo[16]={};

	ESP_LOGI(Azure_TASK_TAG, "**** Azure Service Started Successfully ****");

	//Set azure service up flag and wait for all other servces
	_u32xevent_result = xEventGroupSync( g_xEventGroup,
			AZURE_SERVICE_BIT,
			SYNC_ALL_TASK,
			g_u32TaskSyncTime );

	if(SYNC_ALL_TASK != (_u32xevent_result & SYNC_ALL_TASK))
	{
		/* System reset*/
		comm_system_reboot();
	}

	//Set default azure stat
	g_azure_service_stat = AZURE_WAIT;
	azure_set_valid_stat (AZURE_DISCONNECT);
	azure_set_connection_status( COMM_AZURE_DISCONNECTED );

	while ( 1 )
	{
		switch ( g_azure_service_stat )
		{
		case AZURE_INIT: 
			if (azure_platform_init() == 0)
			{
				//If platform Init Fail
				g_azure_service_stat = AZURE_DEINIT;
				_gu8_platform_init_count++;
			} else {
				_gu8_platform_init_count = 0;
				g_azure_service_stat = AZURE_CONNECT;
				_gu8AzureCommand = AZURE_POWERON_PACKET;
				azure_set_valid_stat (AZURE_CONNECT);
			}
			if( _gu8_platform_init_count >= AZUR_INIT_MAX_RETRY_COUNT)
			{
				g_azure_service_stat = AZURE_WAIT;
			}
			break;

		case AZURE_CONNECT:
			azure_start_iothub(_gu8AzureCommand);
			break;

		case AZURE_DISCONNECT:
			vTaskDelay(1000 / portTICK_PERIOD_MS);
			break;

		case AZURE_DEINIT:
			azure_iothub_platform_deinit();
			g_azure_service_stat = AZURE_WAIT;

			break;
		case AZURE_CHECK_CONNECTION_STRING:
			printf ("Check Connection string ........\r\n");

			//Get connection string from flash
			nvm_get_string (AZURE_CONNECTION_STR, _gu8ConnectoinString);

			//For testing
			_u8result = strlen (_gu8ConnectoinString);
			if(_u8result == 0)
			{
				g_azure_service_stat = AZURE_GET_CONNECTION_STRING;

			} else {
				nvm_get_string (DEVICE_SERIAL_NUM, _u8localSerialNo);
				if (strlen(_u8localSerialNo))
				{
					comm_set_serial_number(_u8localSerialNo);
				}
				g_azure_service_stat = AZURE_INIT;
			}
			break;

		case AZURE_GET_CONNECTION_STRING:
			//Read serial number from Flash
			nvm_get_string (DEVICE_SERIAL_NUM, _u8localSerialNo);

			printf ("Serial Number In Flash ::: %s\r\n", _u8localSerialNo);

			if (strlen(_u8localSerialNo))
			{
				comm_set_serial_number(_u8localSerialNo);
			}

			//Check MCU is power ON or not
			//If MCU is not power on then ESP module is not having serial number
			//Wait for power on packet
			if ( g_MCU_powerOn || (strlen(_u8localSerialNo)))
			{
				_st_httpInfo_In.device_type = DEVICE_ID_AZURE;
				_st_httpInfo_In.request_type = HTTP_POST;
				_st_httpInfo_In.web_server = WEB_SERVER_AZURE;

				if ((STATUS_SUCCESS == http_send_query_get_resp(_st_httpInfo_In)) && (strlen (_gu8ConnectoinString) != 0))
				{
					printf(" HTTP send request get response success\r\n");
					//Set connection string into the Flash
					nvm_set_string (AZURE_CONNECTION_STR, _gu8ConnectoinString);

				} else {
					printf(" HTTP get FOTA request fail \r\n");
					vTaskDelay(5000 / portTICK_PERIOD_MS);
					break;
				}

				g_azure_service_stat = AZURE_CHECK_CONNECTION_STRING;

			}else{
				ESP_LOGI(Azure_TASK_TAG, " *** MCU not yet power on *** ");
				vTaskDelay(2000 / portTICK_PERIOD_MS);
			}
			break;

		case AZURE_WAIT:
		default:
			vTaskDelay(5000 / portTICK_PERIOD_MS);
			break;
		}
	}
}
