#include "common.h"
#include "common.h"
#include "led_control.h"

#define WIFI_SMART_CONFIG_TIME (100)
#define WIFI_DISCONNECT_TIME (1000)
#define INETRNET_FAIL_OFF_TIME (1000)
#define INETRNET_FAIL_ON_TIME (200)
#define AZURE_CON_SUCCESS_TIME (3000)

/****** All globle variabl ***********/
static const char *LED_TASK_TAG = "_LED_";
unsigned char g_led_service_stat = 0;


/** @fn led_stat_change 
 *
 * @brief This function used to change the state of the LED thread
 *
 * @param N.A.
 *.
 *  @return None.(Will not Return from here.)
 */
void led_stat_change ( e_led_control_stat _u32stat_In)
{
	g_led_service_stat = _u32stat_In;
}

/** @fn led_on 
 * 
 * @brief This function used for LED on
 *
 * @param N.A.
 *.
 *  @return None.(Will not Return from here.)
 */
void led_on( void )
{
	gpio_set_level(BLINK_GPIO, 1);
}

/** @fn led_off
 *
 * @brief This function used for LED off
 *
 * @param N.A.
 *.
 *  @return None.(Will not Return from here.)
 */
void led_off( void )
{
	gpio_set_level(BLINK_GPIO, 0);
}

/** @fn led_control_service
 *
 * @brief This function used to start LED control service
 *
 * @param N.A.
 *.
 *  @return None.(Will not Return from here.)
 */
void led_control_service (void *pvParameter)
{
	EventBits_t _u32xevent_result;
	unsigned char _u8Itr = 0;
	ESP_LOGI(LED_TASK_TAG, "**** LED Service Started Successfully ****");

	//Set azure service up flag and wait for all other servces
	_u32xevent_result = xEventGroupSync( g_xEventGroup,
						LED_CONTROL_SERVICE_BIT,
						SYNC_ALL_TASK,
						g_u32TaskSyncTime );

	if(SYNC_ALL_TASK != (_u32xevent_result & SYNC_ALL_TASK))
	{
		printf ("****** Error to set the LED event ********\r\n");
		/*System reset*/
		comm_system_reboot();
	}

	printf ("****** Set LED event ********\r\n");

	//ESP_LOGI(LED_TASK_TAG, "**** Test -1 ****");
	//while(1);
	//Set default azure stat
	g_led_service_stat = LED_INIT;

	while ( 1 )
	{
		switch ( g_led_service_stat )
		{
			case LED_INIT:
				//Initialize LED Pins
				led_off();
				g_led_service_stat  = LED_WAIT;
				//g_led_service_stat  = LED_INTERNET_NOT_AVAILABLE;
				break;
			case LED_WIFI_SMART_CONFIG:
				//Smart Config
				led_on();
				vTaskDelay(WIFI_SMART_CONFIG_TIME / portTICK_PERIOD_MS);
				led_off();
				vTaskDelay(WIFI_SMART_CONFIG_TIME / portTICK_PERIOD_MS);

				break;
			case LED_WIFI_DISCONNECTED:
				//* If wifi disconnected
				//* If wifi continuesly try to connect
				led_on();
				vTaskDelay(WIFI_DISCONNECT_TIME / portTICK_PERIOD_MS);
				led_off();
				vTaskDelay(WIFI_DISCONNECT_TIME / portTICK_PERIOD_MS);
				break;
			case LED_INTERNET_NOT_AVAILABLE:
			case LED_FAIL_TO_CONNECTING_TO_AZURE:
				//Ping to google.com
				led_off();
				vTaskDelay(INETRNET_FAIL_OFF_TIME / portTICK_PERIOD_MS);
				for (_u8Itr = 0; _u8Itr < 3; _u8Itr++)
				{
					led_on();
					vTaskDelay(INETRNET_FAIL_ON_TIME / portTICK_PERIOD_MS);
					led_off();
					vTaskDelay(INETRNET_FAIL_ON_TIME / portTICK_PERIOD_MS);
				}

				break;			
			case LED_WIFI_N_AZURE_CON_SUCCESSFULLY:
				//If Wifi and Azure both are connected
				led_on();
				vTaskDelay(AZURE_CON_SUCCESS_TIME / portTICK_PERIOD_MS);
				led_off();
				vTaskDelay(AZURE_CON_SUCCESS_TIME / portTICK_PERIOD_MS);
				break;

			case LED_WAIT:
			default:
				vTaskDelay(1000 / portTICK_PERIOD_MS);
				break;
		}
	}
}
