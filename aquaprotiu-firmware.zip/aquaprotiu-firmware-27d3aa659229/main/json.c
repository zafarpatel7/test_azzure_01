#include "common.h"
#include "json.h"

//This function used to get the reponse of connection string
unsigned char GetStringFromTag(char *pResponse, char *Output, char *TagIn)
{
	unsigned char lResult = STATUS_SUCCESS;
	char *ptr = NULL;
	do
	{
		if ((pResponse == NULL) || (Output == NULL) || (TagIn == NULL))
		{
			lResult = STATUS_ERROR;
			break;
		}

		//Create JSON Object
		cJSON *proot = cJSON_Parse(pResponse);

		if(proot == NULL)
		{
			lResult = STATUS_ERROR;
			break;
		}

		//Try to remove this
		cJSON *psubObj = cJSON_GetObjectItem(proot, "response");
		if(psubObj == NULL)
		{
			lResult = STATUS_ERROR;
			break;
		}


		ptr = (char *)cJSON_GetObjectItem(psubObj, TagIn);//->valuestring;
		if (ptr == NULL)
		{
			lResult = STATUS_ERROR;
			break;
		} else {
			ptr = (char *)cJSON_GetObjectItem(psubObj, TagIn)->valuestring;
			if (ptr == NULL)
			{
				lResult = STATUS_ERROR;
				break;
			}
		}
		printf ("[Output : %s]", ptr);

		strcpy(Output, ptr);

	}while (0);
	return lResult;
}

#if 0
//Test function for JSON
int TestJSON(void)
{
    char pResponse[12] = {0}; char Output[12] = {0}; char TagIn[12] = "hello";

    /*{
        "name": "Mars",
        "mass": 639e21,
        "moons": [
            {
                "name": "Phobos",
                "size": 70
            },
            {
                "name": "Deimos",
                "size": 39
            }
        ]
    }*/

    char *strJson = "{\"name\" : \"Mars\",\"mass\":639e21,\"moons\":[{\"name\":\"Phobos\",\"size\":70},{\"name\":\"Deimos\",\"size\":39}]} .ad sdf";

    printf("Planet:\n");

    // First, parse the whole thing
    cJSON *root = cJSON_Parse(strJson);

    // Let's get some values
    char *name = cJSON_GetObjectItem(root, "name")->valuestring;
    double mass = cJSON_GetObjectItem(root, "mass")->valuedouble;

    printf("%s, %.2e kgs\n", name, mass); // Note the format! %.2e will print a number with scientific notation and 2 decimals
    // Now let's iterate through the moons array
    cJSON *moons = cJSON_GetObjectItem(root, "moons");

    // Get the count
    int moons_count = cJSON_GetArraySize(moons);
    int i;

    for (i = 0; i < moons_count; i++) {
        printf("Moon:\n");
        // Get the JSON element and then get the values as before
        cJSON *moon = cJSON_GetArrayItem(moons, i);
        char *name = cJSON_GetObjectItem(moon, "name")->valuestring;
        int size = cJSON_GetObjectItem(moon, "size")->valueint;
        printf("%s, %d kms\n", name, size);
    }

    // Finally remember to free the memory!
    cJSON_Delete(root);
    GetStringFromTag(&pResponse, &Output, &TagIn);

    return 0;
}
#endif
