#ifndef _FLASH_H_
#define _FLASH_H_

typedef enum
{
	FLASH_ERASE = 0,
	FLASH_GETINIT,
	FLASH_GETSTR,
	FLASH_SETINIT,
	FLASH_SETSTR
} flash_command;

void nvm_set_string ( char* parameter, char *valueIn );
void nvm_get_string ( char* parameter, char *valueIn );
void nvm_set_int ( char* parameter, char *valueIn );
void nvm_erase_all ( void );
void nvs_config ( void );
void nvm_erase_string ( char* parameter, char *valueIn );
#endif
