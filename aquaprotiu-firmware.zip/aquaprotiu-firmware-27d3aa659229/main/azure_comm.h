#ifndef _AZURE_COMM_H_
#define _AZURE_COMM_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"

/************ Extern Azure Variable *********/
extern char gDataForController[512];
extern bool gSendDataToController;

/********* All Functions *******************/
void azure_set_valid_stat ( unsigned char _u8stat_In );
unsigned char azure_get_valid_stat ( void );
void azure_send_command (unsigned char _u8azure_command_In);
void azure_service(void *pvParameter);
void azure_set_state ( unsigned char _u8stat_in );
unsigned char azure_get_state ( void );
int azure_get_connection_status ( void );
void azure_set_connection_status ( int val_In);


#ifdef __cplusplus
}
#endif
#endif
