#include "common.h"
#include "data_indication.h"

/********** All Globle Variable **************/ 
static const char *DI_TASK_TAG = "_DI_";
unsigned char g_DI_service_stat = 0;

/** @fn data_indication_service
 *
 * @brief This function used to start Data Indication
 *
 * @param N.A.
 *.
 *  @return None.(Will not Return from here.)
 */
void data_indication_service (void *pvParameter)
{
	EventBits_t _u32xevent_result;

	ESP_LOGI(DI_TASK_TAG, "**** Data Indication Service Started Successfully ****");

	//Set azure service up flag and wait for all other servces
	_u32xevent_result = xEventGroupSync( g_xEventGroup,
			DATA_INDICATION_SERVICE_BIT,
			SYNC_ALL_TASK,
			g_u32TaskSyncTime );

	if(SYNC_ALL_TASK != (_u32xevent_result & SYNC_ALL_TASK))
	{
		/* TODO: System reset*/
		comm_system_reboot();
	}

	//Set default azure stat
	g_DI_service_stat = DI_OFF;

	while ( 1 )
	{
		switch ( g_DI_service_stat )
		{
			case DI_INIT:
				//Initialize LED Pins
				g_DI_service_stat  = DI_OFF;
				break;
			case DI_DATA_FROM_AZURE:
				//LED Indication if data received from azure
				g_DI_service_stat  = DI_WAIT;				
				break;
			case DI_DATA_FROM_MCU:
				//LED Indication If data received from MCU
				g_DI_service_stat  = DI_WAIT;				
				break;
			case DI_DATA_SEND_TO_AZURE:
				//LED Indication If data send to Azure
				g_DI_service_stat  = DI_WAIT;				
				break;
			case DI_DATA_SEND_TO_MCU:
				//LED Indication If data send to MCU
				g_DI_service_stat  = DI_WAIT;				
				break;
			case DI_OFF:
				g_DI_service_stat  = LED_WAIT;
				break;
			case DI_WAIT:
			default:
				vTaskDelay(10000 / portTICK_PERIOD_MS);
				break;
		}
	}
}
