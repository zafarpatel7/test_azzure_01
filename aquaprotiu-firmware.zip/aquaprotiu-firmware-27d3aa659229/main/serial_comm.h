#ifndef _SERIAL_COMM_H_
#define _SERIAL_COMM_H_

void SC_TX_Stat_change ( int _u32TxStat );
void serial_comm_service(void *param);
void tx_task ( void *param );
unsigned char SC_TX_update_tx_event ( int _u32event_In);
unsigned char SC_RX_update_rx_event ( int _u32event_In);
unsigned char SC_Get_Board_serial_Number(unsigned char *_u8rx_data_In, char *SerialNum);
unsigned char SC_Get_MCU_version(unsigned char *_u8rx_data_In, char *_u8major_In, char *_u8minor_In);


#endif
