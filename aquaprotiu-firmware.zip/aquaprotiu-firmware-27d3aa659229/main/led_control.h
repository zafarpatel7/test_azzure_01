#ifndef _LED_CONTROL_H_
#define _LED_CONTROL_H_

void led_stat_change ( e_led_control_stat _u32stat_In);
void led_control_service (void *pvParameter);
void led_on( void );
void led_off( void );

#endif
