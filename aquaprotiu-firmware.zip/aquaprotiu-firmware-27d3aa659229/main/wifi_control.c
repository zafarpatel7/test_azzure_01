#include "common.h"
#include "wifi_control.h"
#include "flash.h"

/**** Define ****************/
#define WIFI_SSID "SSID"
#define WIFI_PASS "PassWD"
#define DEFAULT_WIFI_SSID CONFIG_WIFI_SSID
#define DEFAULT_WIFI_PASS CONFIG_WIFI_PASSWORD
#define WIFI_RETRY_TIME_IN_SEC 				(10)
#define WIFI_SERVICE_RXQ_TIMEOUT 			100   /*The maximum amount of time the task
											should block waiting for an item*/

/****** All globle variabl ***********/
volatile e_wifi_state_type g_wifi_serv_state;
volatile e_wifi_state_type g_wifi_current_valid_stat;
static const char *Wifi_TASK_TAG = "_Wifi_";
char g_ssid[32] = {0};
char g_pass[32] = {0};
char g_reconnect[2] = {0};
TickType_t _tsend_timeout = 100;
int _ret_status = 0;
wifi_config_t g_wifi_config = {0};
unsigned char _gu8SC_In_Start = 0;

/********** All extern variable *******/
extern EventGroupHandle_t g_xEventGroup;

/*
 * This is retry count of WiFi. This count reset in case of Wifi Connected 
 * successfully
 */
static unsigned char _gu8Retry = 0;
/*
 * This flag Set if WiFi module using default SSID
 */
static unsigned char _gu8DefaultSSIDUsing = 0;
/*
 * This flag Set if smart config thread started
 */
static unsigned char _gu8SC_In_Progress = 0;

//This function used to set the valid wifi stat
void wifi_set_valid_stat ( unsigned char _u8stat_In )
{
	g_wifi_current_valid_stat = _u8stat_In;
}

//This function used to get the valid stat of wifi
unsigned char wifi_get_valid_stat ( void )
{
	return g_wifi_current_valid_stat;
}

/** @fn wifi_event_handler
 *
 * @brief This is call back function which received all WIFI events
 *
 * @param 
 *.
 *  @return current WIFI SERVICE STATE
 */
static esp_err_t wifi_event_handler(void *ctx, system_event_t *event)
{
	char _u8localSerialNo[32] = {0}, _u8localHostName[32] = {0};

	switch(event->event_id) 
	{
		case SYSTEM_EVENT_STA_START:
			ESP_LOGI(Wifi_TASK_TAG, "Received Start event");
			//Get Serial Numebr
			nvm_get_string (DEVICE_SERIAL_NUM, _u8localSerialNo);
			if (strlen(_u8localSerialNo))
			{
				sprintf(_u8localHostName, "%s_%s", PRODUCT_NAME,_u8localSerialNo);
			} else {
				sprintf(_u8localHostName, "%s", PRODUCT_NAME);
			}

			printf ("Host Name :: %s\n", _u8localHostName);
			ESP_ERROR_CHECK(tcpip_adapter_set_hostname(TCPIP_ADAPTER_IF_STA , (const char*)&_u8localHostName))
				esp_wifi_connect();
			break;

		case SYSTEM_EVENT_STA_GOT_IP:
			ESP_LOGI(Wifi_TASK_TAG, "Received Got IP Event");
			nvm_erase_string(WIFI_SSID, NULL);
			nvm_erase_string(WIFI_PASS, NULL);
			nvm_set_string(WIFI_SSID, (char *)g_wifi_config.sta.ssid);
			nvm_set_string(WIFI_PASS, (char *)g_wifi_config.sta.password);
			wifi_stat_change( WIFI_CONNECTED );
			xEventGroupSetBits(g_xServiceStatEventGroup, COMM_WIFI_CONNECTED);
			xEventGroupSetBits(g_xSmartConfigEventGroup, SMART_WIFI_CONNECTED);

			break;

		case SYSTEM_EVENT_STA_DISCONNECTED:

			ESP_LOGI(Wifi_TASK_TAG, "Received Disconnect Event :: _gu8SC_In_Start(%d) | _gu8SC_In_Progress(%d)",_gu8SC_In_Start,_gu8SC_In_Progress);

			if ( _gu8SC_In_Start )
			{
				//If Wifi is in disconnect mode and Rx received "WIFI_CONFIG"
				_gu8SC_In_Start = 0;
				xEventGroupSetBits(g_xServiceStatEventGroup, COMM_WIFI_DISCONNECT);
				xTaskCreate(wifi_smart_config_service, "smart config service", 4096, NULL, 3, NULL);
			}
			else if ( _gu8SC_In_Progress )
			{
				//* If Smart Config fail becasue of wrong SSID and PASSWORD
				xEventGroupSetBits(g_xSmartConfigEventGroup, SMART_WIFI_DISCONNECT);
			}
			else
			{
				//Call reconnect
				wifi_stat_change (WIFI_RECONNECT);
			}
			break;

		case SYSTEM_EVENT_STA_STOP:
			ESP_LOGI(Wifi_TASK_TAG, "******* STA_STOP_EVENT *******");
			break;

		case SYSTEM_EVENT_STA_CONNECTED:
			ESP_LOGI(Wifi_TASK_TAG, "******* STA_CONNECTED_EVENT *******");
			_gu8Retry = 0;
			break;

		case SYSTEM_EVENT_STA_LOST_IP:
			ESP_LOGI(Wifi_TASK_TAG, "******* STA_LOST_IP_EVENT *******");
			wifi_stat_change (WIFI_RECONNECT);
			if (_gu8SC_In_Progress)
			{
				printf("<<<<< Sent Smart Wifi Disconnect Event >>>>>>>\r\n");
				xEventGroupSetBits(g_xSmartConfigEventGroup, SMART_WIFI_DISCONNECT);
			}

			break;

		case SYSTEM_EVENT_SCAN_DONE:
			ESP_LOGI(Wifi_TASK_TAG, "******* SCAN_DONE_EVENT *******");
			break;

		case SYSTEM_EVENT_WIFI_READY :
			ESP_LOGI(Wifi_TASK_TAG, "******* WIFI_READY_EVENT *******");
			break;

		default:
			break;
	}

	return ESP_OK;
}

/** @fn wifi_Init
 *
 * @brief This function used for Wifi Initilization
 *
 * @param 
 *.
 *  @return current WIFI SERVICE STATE
 */
static void wifi_Init ( void )
{
	printf ("*** Wifi Init start ***\r\n");
	// TCP/IP initialization
	tcpip_adapter_init();

	//Event loop initialization
	ESP_LOGI(Wifi_TASK_TAG, "Initialise Wifi : Event Loop Init");
	ESP_ERROR_CHECK( esp_event_loop_init(wifi_event_handler, NULL) );

	wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();

	//ESP Wifi Initialization
	ESP_LOGI(Wifi_TASK_TAG, "Initialise Wifi : Wifi Init");
	ESP_ERROR_CHECK( esp_wifi_init(&cfg) );

	//Set the WiFi station mode
	ESP_LOGI(Wifi_TASK_TAG, "Initialise Wifi : Set Wifi Mode");
	ESP_ERROR_CHECK( esp_wifi_set_mode(WIFI_MODE_STA) );

	//Set default / user SSID and PASSWORD
	printf ("@harshal : %s || %s @@@@\r\n",g_wifi_config.sta.ssid,g_wifi_config.sta.password);
	ESP_ERROR_CHECK( esp_wifi_set_config(ESP_IF_WIFI_STA, &g_wifi_config) );

	printf ("*** Wifi Init End ***\r\n");
	return;
}

/** @fn wifi_smartconfig_callback
 *
 * @brief This is a call back function for smart config 
 *
 * @param 
 *.
 *  @return current WIFI SERVICE STATE
 */
static void wifi_smartconfig_callback( smartconfig_status_t status, void *pdata )
{
	switch (status)
	{
		case SC_STATUS_WAIT:
			ESP_LOGI(Wifi_TASK_TAG, "SC_STATUS_WAIT");
			break;
		case SC_STATUS_FIND_CHANNEL:
			ESP_LOGI(Wifi_TASK_TAG, "SC_STATUS_FINDING_CHANNEL");
			break;
		case SC_STATUS_GETTING_SSID_PSWD:
			ESP_LOGI(Wifi_TASK_TAG, "SC_STATUS_GETTING_SSID_PSWD");
			break;
		case SC_STATUS_LINK:
			ESP_LOGI(Wifi_TASK_TAG, "SC_STATUS_LINK");
			wifi_config_t *wifi_config = pdata;
			ESP_LOGI(Wifi_TASK_TAG, "SSID:%s", wifi_config->sta.ssid);
			ESP_LOGI(Wifi_TASK_TAG, "PASSWORD:%s", wifi_config->sta.password);
			stpcpy((char *)g_ssid, (char*)wifi_config->sta.ssid);
			stpcpy((char *)g_pass, (char *)wifi_config->sta.password);
			stpcpy((char *)g_wifi_config.sta.ssid, g_ssid);
			stpcpy((char *)g_wifi_config.sta.password, g_pass);

			ESP_ERROR_CHECK( esp_wifi_disconnect() );
			ESP_ERROR_CHECK( esp_wifi_set_config(ESP_IF_WIFI_STA, wifi_config) );
			ESP_ERROR_CHECK( esp_wifi_connect() );
			break;
		case SC_STATUS_LINK_OVER:
			ESP_LOGI(Wifi_TASK_TAG, "SC_STATUS_LINK_OVER");
			if (pdata != NULL) {
				uint8_t phone_ip[4] = { 0 };
				memcpy(phone_ip, (uint8_t* )pdata, 4);
				ESP_LOGI(Wifi_TASK_TAG, "Phone ip: %d.%d.%d.%d\n", phone_ip[0], phone_ip[1], phone_ip[2], phone_ip[3]);
			}
			//Change following event as per changes
			xEventGroupSetBits(g_xServiceStatEventGroup, COMM_SMARTCONFIG_DONE);
			xEventGroupSetBits(g_xSmartConfigEventGroup, SMART_SMARTCONFIG_DONE);
			break;
		default:
			break;
	}
}

/** @fn wifi_smart_config_service
 *
 * @brief This is a smart config service which is start at the time of key press
 *
 * @param N.A
 *.
 *  @return N.A
 */
void wifi_smart_config_service (void * parm)
{
	EventBits_t uxBits;

	_gu8SC_In_Progress = 1; 

	ESP_LOGI(Wifi_TASK_TAG, "**** SmartConfig Service Started Successfully ****");

	//Set ESPTOUCH Protocol
	ESP_ERROR_CHECK( esp_smartconfig_set_type(SC_TYPE_ESPTOUCH) );

	esp_esptouch_set_timeout(60);

	//Set Smart Config Status Callback
	ESP_ERROR_CHECK( esp_smartconfig_start(wifi_smartconfig_callback) );

	//Inform Smart Config event prograss to the event thread
	xEventGroupSetBits(g_xServiceStatEventGroup, COMM_SMARTCONFIG_IN_PROGRESS);

	while (1)
	{
		//Need to handle WIFI_CONNECTED, WIFI_DISCONNECTED and ESPTOUCH_DONE event
		uxBits = xEventGroupWaitBits(g_xSmartConfigEventGroup, SMART_WIFI_CONNECTED | SMART_SMARTCONFIG_DONE | SMART_WIFI_DISCONNECT, true, false, portMAX_DELAY);

		if(uxBits & SMART_WIFI_CONNECTED)
		{
			ESP_LOGI(Wifi_TASK_TAG, "WiFi Connected to ap");
		}

		if(uxBits & SMART_WIFI_DISCONNECT)
		{
			ESP_LOGI(Wifi_TASK_TAG, "WiFi Disconnected");
			esp_smartconfig_stop();
			_gu8SC_In_Progress = 0; 
			xEventGroupClearBits(g_xSmartConfigEventGroup, SMART_WIFI_DISCONNECT);
			vTaskDelete(NULL);
		}

		if(uxBits & SMART_SMARTCONFIG_DONE)
		{
			ESP_LOGI(Wifi_TASK_TAG, "Smart Config over");
			esp_smartconfig_stop();
			_gu8SC_In_Progress = 0;
			vTaskDelete(NULL);
		}
	}
}


/** @fn wifi_stat_change
 *
 * @brief This function used to change the Wifi service stat
 *
 * @param N.A
 *.
 *  @return N.A
 */
void wifi_stat_change (e_wifi_state_type _u8Stat_In)
{
	g_wifi_serv_state = _u8Stat_In;
}


/** @fn wifi_control_service
 *
 * @brief This function used to start Wifi service
 *
 * @param N.A.
 *.
 *  @return None.(Will not Return from here.)
 */
void wifi_control_service(void *param)
{
	EventBits_t _u32xevent_result;
	unsigned char _u8local_pass, _u8local_ssid;
	unsigned char _u8localresult = 0, _u8localCount = 0;

	/* wifi service queue message */
	msg_info _st_wifi_srv_msg;
	//msg_info _st_wifi_dummy_msg;

	ESP_LOGI(Wifi_TASK_TAG, "**** Wifi Service Started Successfully ****");

	_u32xevent_result = xEventGroupSync( g_xEventGroup,
			WIFI_SERVICE_BIT,
			SYNC_ALL_TASK,
			g_u32TaskSyncTime );

	if(SYNC_ALL_TASK != (_u32xevent_result & SYNC_ALL_TASK))
	{
		/* System reset*/
		comm_system_reboot();
	}

	wifi_stat_change( WIFI_CHECK_USER_SSID_PASS );
	xEventGroupSetBits(g_xServiceStatEventGroup, COMM_WIFI_DISCONNECT);

	while (1)
	{
		//Wait for input message here
		if(pdTRUE == xQueueReceive(g_wifi_control_req_queue, &_st_wifi_srv_msg, WIFI_SERVICE_RXQ_TIMEOUT))
		{
			if(WIFI_SERVICE_REQID == _st_wifi_srv_msg.service_id)
			{
				printf ("$$$$$$$ INFO : We received the stat change command (%d) $$$$$$\r\n", _st_wifi_srv_msg.cmd);
				wifi_stat_change (_st_wifi_srv_msg.cmd);
			}
		}

		switch ( g_wifi_serv_state )
		{
			case WIFI_INIT :
				wifi_Init();
				wifi_stat_change (WIFI_START);
				break;

			case WIFI_START:
				//Start WIFI according to current configuration. it create station control block
				ESP_LOGI(Wifi_TASK_TAG, "Initialise Wifi : Start Wifi");
				ESP_ERROR_CHECK( esp_wifi_start() );
				//				wifi_stat_change (WIFI_CONNECTING);
				wifi_stat_change (WIFI_WAIT);
				break;

			case WIFI_CONNECTED :
				//Connected Event Raise in event handler
				wifi_set_valid_stat ( WIFI_CONNECTED );
				wifi_stat_change ( WIFI_WAIT );
				break;

			case WIFI_DEINIT :
				/* This API always return PASS no need to take care. */
				xQueueReset(g_wifi_control_req_queue);
				break;

			case WIFI_DISCONNECT :
				wifi_set_valid_stat ( WIFI_DISCONNECT );
				wifi_stat_change  (WIFI_WAIT);
				break;

			case WIFI_CHECK_USER_SSID_PASS:
				//Get Stored SSID and PASSWORD from flash
				nvm_get_string(WIFI_SSID, g_ssid);
				printf ("*** SSID : %s | %d ****\r\n", g_ssid, strlen( g_ssid ));
				nvm_get_string(WIFI_PASS, g_pass);
				printf ("*** Pass : %s | %d ***\r\n", g_pass, strlen( g_pass ));
				_u8local_ssid = strlen ( g_ssid );
				_u8local_pass = strlen ( g_pass );

				//Validate User name and Password
				if ((0 == _u8local_ssid) || (0 == _u8local_pass))
				{
					//User entered password not present
					//update SSID and PASS with default value
					memset((char *)g_wifi_config.sta.ssid, '\0', sizeof(g_wifi_config.sta.ssid));
					memset((char *)g_wifi_config.sta.password, '\0', sizeof(g_wifi_config.sta.password));
					stpcpy((char *)g_wifi_config.sta.ssid, DEFAULT_WIFI_SSID);
					stpcpy((char *)g_wifi_config.sta.password, DEFAULT_WIFI_PASS);

					printf ("*** Default SSID : %s ****\r\n", g_wifi_config.sta.ssid);
					printf ("*** Default Pass : %s ***\r\n", g_wifi_config.sta.password);

					_gu8DefaultSSIDUsing = 1;

				} else {

					//If User entered SSID and Password Present
					memset((char *)g_wifi_config.sta.ssid, '\0', sizeof(g_wifi_config.sta.ssid));
					memset((char *)g_wifi_config.sta.password, '\0', sizeof(g_wifi_config.sta.password));
					stpcpy((char *)g_wifi_config.sta.ssid, g_ssid);
					stpcpy((char *)g_wifi_config.sta.password, g_pass);
					_gu8DefaultSSIDUsing = 0;
				}

				wifi_stat_change (WIFI_INIT);
				break;

			case WIFI_GET_USER_SSID_PASS:
				//@This stat call at the time key press
				//If Smart Config is in process then skip this event
				printf ("@@@@@@@ Message received into the switch case @@@@@@@\r\n");
				_u8localresult = wifi_get_valid_stat();

				if ( _u8localresult == WIFI_DISCONNECT )
				{
					if (0 == _gu8SC_In_Progress)
					{
						printf("**** Calling smart config thread *****\r\n");
						xTaskCreate(wifi_smart_config_service, "smart config service", 4096, NULL, 3, NULL);
					}
				}
				else if ( _u8localresult == WIFI_CONNECTED )
				{
					if (0 == _gu8SC_In_Progress)
					{
						printf("**** Called Wifi Disconnect *****\r\n");
						//Disconnect Wifi
						esp_wifi_disconnect();
						//Start Smart Config Thread
						printf("**** Calling smart config thread *****\r\n");
						_gu8SC_In_Start = 1;
					}
				}
				else
				{
					printf ("***** Invalid Stat of wifi found [ Try again ] *****\r\n");
				}


				wifi_set_valid_stat ( WIFI_GET_USER_SSID_PASS );
				wifi_stat_change (WIFI_WAIT);
				break;

			case WIFI_RECONNECT:
				wifi_set_valid_stat ( WIFI_DISCONNECT );
				vTaskDelay(1000 / portTICK_PERIOD_MS);

				if (_u8localCount == WIFI_RETRY_TIME_IN_SEC)
				{
					//If gets Wifi disconnected then retry using stored SSID and PASS
					nvm_get_string ( WIFI_SSID, g_ssid );
					nvm_get_string ( WIFI_PASS, g_pass );

					//Validate User name and Password
					if ((0 == strlen ( g_ssid )) || (0 == strlen ( g_pass )))
					{
						//User entered password not present
						//update SSID and PASS with default value
						memset((char *)g_wifi_config.sta.ssid, '\0', sizeof(g_wifi_config.sta.ssid));
						memset((char *)g_wifi_config.sta.password, '\0', sizeof(g_wifi_config.sta.password));
						stpcpy((char *)g_wifi_config.sta.ssid, DEFAULT_WIFI_SSID);
						stpcpy((char *)g_wifi_config.sta.password, DEFAULT_WIFI_PASS);

						printf ("*** Default SSID : %s ****\r\n", g_wifi_config.sta.ssid);
						printf ("*** Default Pass : %s ***\r\n", g_wifi_config.sta.password);

						_gu8DefaultSSIDUsing = 1;

					} else {

						//If User entered SSID and Password Present
						memset((char *)g_wifi_config.sta.ssid, '\0', sizeof(g_wifi_config.sta.ssid));
						memset((char *)g_wifi_config.sta.password, '\0', sizeof(g_wifi_config.sta.password));
						stpcpy((char *)g_wifi_config.sta.ssid, g_ssid);
						stpcpy((char *)g_wifi_config.sta.password, g_pass);
						_gu8DefaultSSIDUsing = 0;
					}

					_u8localCount = 0;
					xEventGroupSetBits(g_xServiceStatEventGroup, COMM_WIFI_DISCONNECT);
					esp_wifi_connect();
				}

				_u8localCount++;

				break;

			case WIFI_WAIT:
			default:
				vTaskDelay(1000 / portTICK_PERIOD_MS);
				break;
		}
	}
}
